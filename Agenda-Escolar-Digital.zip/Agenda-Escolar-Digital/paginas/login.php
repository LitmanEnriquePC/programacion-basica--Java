<?php
session_start();
require_once __DIR__ . '/../sql/conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $dni = $_POST['dni'];
    $password = $_POST['password'];
    
    try {
        // Consulta para obtener usuario con datos de persona y rol
        $sql = "SELECT u.id as usuario_id, u.contraseña, p.nombres, p.apellidos, p.dni, p.correo, r.nombre_rol 
                FROM usuarios u 
                INNER JOIN personas p ON u.persona_id = p.id 
                INNER JOIN roles r ON u.rol_id = r.id 
                WHERE p.dni = ? AND u.activo = TRUE";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$dni]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($usuario && password_verify($password, $usuario['contraseña'])) {
            // Guardar datos en sesión
            $_SESSION['usuario_id'] = $usuario['usuario_id'];
            $_SESSION['dni'] = $usuario['dni'];
            $_SESSION['nombres'] = $usuario['nombres'];
            $_SESSION['apellidos'] = $usuario['apellidos'];
            $_SESSION['correo'] = $usuario['correo'];
            $_SESSION['rol'] = $usuario['nombre_rol'];
            
            // Redirigir al dashboard principal
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "DNI o contraseña incorrectos";
        }
        
    } catch(PDOException $e) {
        $error = "Error en la base de datos";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
</head>
<body>
    <h2>Iniciar Sesión</h2>
    
    <?php if (isset($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
    
    <?php if (isset($_GET['mensaje'])): ?>
        <p style="color: green;"><?php echo htmlspecialchars($_GET['mensaje']); ?></p>
    <?php endif; ?>
    
    <form method="POST" action="login.php">
        <label for="dni">DNI:</label><br>
        <input type="text" id="dni" name="dni" required><br><br>
        
        <label for="password">Contraseña:</label><br>
        <input type="password" id="password" name="password" required><br><br>
        
        <input type="submit" value="Iniciar Sesión"><br><br>
    </form>

    
    <a href="recuperar-cuenta/form_recuperacion.php">Olvidaste tu contraseña</a>
</body>
</html>