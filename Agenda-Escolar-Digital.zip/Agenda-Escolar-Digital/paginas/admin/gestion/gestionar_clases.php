<?php
// gestionar_usuarios.php
// Archivo para gestionar usuarios con búsqueda por DNI o correo electrónico.
// Incluye funcionalidades de actualizar y eliminar (desactivar).
// Usa la estructura normalizada: JOIN entre usuarios, personas y roles.
// Eliminar = desactivar (activo = FALSE).

require __DIR__ . '/../../../sql/conexion.php';

$usuarios = [];
$error = '';
$success = '';
$edit_id = $_GET['edit'] ?? null;
$search_type = '';
$search_value = '';

// Si es POST, manejar acciones
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Handle delete (desactivar)
    if (isset($_POST['delete'])) {
        $user_id = (int)$_POST['user_id'];
        try {
            $stmt = $pdo->prepare("UPDATE usuarios SET activo = FALSE WHERE id = ?");
            $stmt->execute([$user_id]);
            $success = 'Usuario desactivado exitosamente.';
            $edit_id = null; // Salir del modo edición
        } catch (PDOException $e) {
            $error = 'Error al desactivar usuario: ' . $e->getMessage();
        }
    }

    // Handle update
    if (isset($_POST['update'])) {
        $user_id = (int)$_POST['user_id'];
        $nombres = trim($_POST['nombres']);
        $apellidos = trim($_POST['apellidos']);
        $dni = trim($_POST['dni']);
        $correo = trim($_POST['correo']);
        $rol_id = (int)$_POST['rol_id'];

        if (empty($nombres) || empty($apellidos) || empty($dni) || empty($correo)) {
            $error = 'Todos los campos son requeridos.';
        } else {
            try {
                $pdo->beginTransaction();

                // Obtener persona_id del usuario
                $stmt = $pdo->prepare("SELECT persona_id FROM usuarios WHERE id = ?");
                $stmt->execute([$user_id]);
                $persona_id = $stmt->fetchColumn();

                if (!$persona_id) {
                    throw new Exception('Usuario no encontrado.');
                }

                // Verificar unicidad DNI (excluyendo el actual)
                $check_stmt = $pdo->prepare("SELECT id FROM personas WHERE dni = ? AND id != ?");
                $check_stmt->execute([$dni, $persona_id]);
                if ($check_stmt->fetch()) {
                    throw new Exception('El DNI ya está registrado en otro usuario.');
                }

                // Verificar unicidad correo (excluyendo el actual)
                $check_stmt = $pdo->prepare("SELECT id FROM personas WHERE correo = ? AND id != ?");
                $check_stmt->execute([$correo, $persona_id]);
                if ($check_stmt->fetch()) {
                    throw new Exception('El correo electrónico ya está registrado en otro usuario.');
                }

                // Update persona
                $stmt = $pdo->prepare("UPDATE personas SET nombres = ?, apellidos = ?, dni = ?, correo = ? WHERE id = ?");
                $stmt->execute([$nombres, $apellidos, $dni, $correo, $persona_id]);

                // Update rol
                $stmt = $pdo->prepare("UPDATE usuarios SET rol_id = ? WHERE id = ?");
                $stmt->execute([$rol_id, $user_id]);

                $pdo->commit();
                $success = 'Usuario actualizado exitosamente.';
                $edit_id = null; // Salir del modo edición
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = 'Error al actualizar usuario: ' . $e->getMessage();
            } catch (PDOException $e) {
                $pdo->rollBack();
                $error = 'Error en la base de datos: ' . $e->getMessage();
            }
        }
    }

    // Handle search
    if (isset($_POST['search'])) {
        $search_type = $_POST['search_type'] ?? '';
        $search_value = trim($_POST['search_value'] ?? '');

        if (empty($search_type)) {
            $error = 'Por favor, selecciona un tipo de búsqueda.';
        } elseif (empty($search_value)) {
            $error = 'Por favor, ingresa un valor para buscar.';
        } else {
            try {
                $sql = "SELECT u.id, p.dni, p.correo AS email, p.nombres AS nombre, p.apellidos, r.nombre_rol AS rol
                        FROM usuarios u 
                        JOIN personas p ON u.persona_id = p.id 
                        JOIN roles r ON u.rol_id = r.id 
                        WHERE u.activo = TRUE AND ";
                $params = [];
                
                if ($search_type === 'dni') {
                    $sql .= "p.dni LIKE :value";
                    $params[':value'] = '%' . $search_value . '%';
                } elseif ($search_type === 'email') {
                    $sql .= "p.correo LIKE :value";
                    $params[':value'] = '%' . $search_value . '%';
                }
                
                $sql .= " ORDER BY p.nombres";
                
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
                $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if (empty($usuarios)) {
                    $error = 'No se encontraron usuarios con ese criterio.';
                }
            } catch (PDOException $e) {
                $error = 'Error en la consulta: ' . $e->getMessage();
            }
        }
    }
}

// Si no hay búsqueda activa, cargar todos los usuarios activos
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || (!isset($_POST['search']) && empty($usuarios))) {
    if (!isset($_POST['search'])) {
        try {
            $sql = "SELECT u.id, p.dni, p.correo AS email, p.nombres AS nombre, p.apellidos, r.nombre_rol AS rol
                    FROM usuarios u 
                    JOIN personas p ON u.persona_id = p.id 
                    JOIN roles r ON u.rol_id = r.id 
                    WHERE u.activo = TRUE 
                    ORDER BY p.nombres";
            $stmt = $pdo->query($sql);
            $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $error = 'Error al cargar usuarios: ' . $e->getMessage();
        }
    }
}

// Fetch edit data
$edit_data = null;
if ($edit_id) {
    try {
        $sql = "SELECT u.id, p.dni, p.correo AS email, p.nombres AS nombre, p.apellidos, u.rol_id
                FROM usuarios u 
                JOIN personas p ON u.persona_id = p.id 
                WHERE u.id = ? AND u.activo = TRUE";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$edit_id]);
        $edit_data = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$edit_data) {
            $error = 'Usuario no encontrado o inactivo.';
            $edit_id = null;
        }
    } catch (PDOException $e) {
        $error = 'Error al cargar datos para edición: ' . $e->getMessage();
        $edit_id = null;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Usuarios</title>
    <link rel="stylesheet" href="../../../CSS/gestionar_clases.css">
</head>
<body>
    <div class="card">
        <h1>Gestionar Usuarios</h1>
        
        <?php if ($success): ?>
            <div class="message success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="message error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($edit_id && $edit_data): ?>
            <div class="edit-section">
                <h2>Editar Usuario</h2>
                <form method="POST">
                    <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($edit_data['id']); ?>">
                    <div class="form-group">
                        <label for="nombres">Nombres:</label>
                        <input type="text" id="nombres" name="nombres" value="<?php echo htmlspecialchars($edit_data['nombre']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="apellidos">Apellidos:</label>
                        <input type="text" id="apellidos" name="apellidos" value="<?php echo htmlspecialchars($edit_data['apellidos']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="dni">DNI:</label>
                        <input type="text" id="dni" name="dni" value="<?php echo htmlspecialchars($edit_data['dni']); ?>" required maxlength="8" pattern="[0-9]{8}">
                    </div>
                    <div class="form-group">
                        <label for="correo">Correo Electrónico:</label>
                        <input type="email" id="correo" name="correo" value="<?php echo htmlspecialchars($edit_data['email']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="rol_id">Rol:</label>
                        <select id="rol_id" name="rol_id" required>
                            <?php 
                            try {
                                $stmt = $pdo->query("SELECT id, nombre_rol FROM roles ORDER BY nombre_rol");
                                while ($rol = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                    $selected = ($rol['id'] == $edit_data['rol_id']) ? 'selected' : '';
                                    echo "<option value='{$rol['id']}' $selected>" . htmlspecialchars($rol['nombre_rol']) . "</option>";
                                }
                            } catch (PDOException $e) {
                                echo "<option value=''>Error cargando roles</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div style="text-align: center; margin-top: 20px;">
                        <button type="submit" name="update" class="btn-primary">Actualizar Usuario</button>
                        <a href="gestionar_usuarios.php" class="btn-secondary">Cancelar</a>
                    </div>
                </form>
            </div>
            <hr style="margin: 30px 0;">
        <?php endif; ?>
        
        <div class="search-form">
            <h3>Buscar Usuario</h3>
            <form method="POST">
                <select name="search_type" required>
                    <option value="">Selecciona tipo de búsqueda</option>
                    <option value="dni" <?php echo ($search_type === 'dni') ? 'selected' : ''; ?>>DNI</option>
                    <option value="email" <?php echo ($search_type === 'email') ? 'selected' : ''; ?>>Correo Electrónico</option>
                </select>
                <input type="text" name="search_value" placeholder="Ingresa DNI o email" value="<?php echo htmlspecialchars($search_value); ?>" required>
                <button type="submit" name="search">Buscar</button>
                <?php if ($search_type && $search_value): ?>
                    <a href="gestionar_usuarios.php" style="margin-left: 10px; color: #007bff; text-decoration: none;">Ver todos</a>
                <?php endif; ?>
                <a href="../../dashboard.php" class="btn">Volver al Dashboard</a>
            </form>
        </div>
        
        <?php if (!empty($usuarios)): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>DNI</th>
                        <th>Correo Electrónico</th>
                        <th>Nombre</th>
                        <th>Apellidos</th>
                        <th>Rol</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($usuarios as $usuario): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($usuario['id']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['dni']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['email']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['nombre']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['apellidos']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['rol']); ?></td>
                            <td class="actions">
                                <a href="?edit=<?php echo $usuario['id']; ?>">Editar</a>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="user_id" value="<?php echo $usuario['id']; ?>">
                                    <button type="submit" name="delete" onclick="return confirm('¿Está seguro de desactivar este usuario?')">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="text-align: center; margin-top: 20px; color: #666;">No hay usuarios activos para mostrar.</p>
        <?php endif; ?>
    </div>
</body>
</html>