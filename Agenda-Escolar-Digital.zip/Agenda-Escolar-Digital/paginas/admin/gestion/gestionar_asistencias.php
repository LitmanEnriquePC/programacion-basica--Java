<?php
// gestionar_clases.php
require __DIR__ . '/../../../sql/conexion.php';

// Fetch grades from the database
$stmt_grados = $pdo->query("SELECT id, nombre FROM grados ORDER BY nivel_numerico");
$grados = $stmt_grados->fetchAll(PDO::FETCH_ASSOC);

// Fetch sections from the database
$stmt_secciones = $pdo->query("SELECT id, nombre FROM secciones ORDER BY nombre");
$secciones = $stmt_secciones->fetchAll(PDO::FETCH_ASSOC);

// Fetch students based on selected grade and section
$estudiantes = [];
if (isset($_GET['grado'], $_GET['seccion'])) {
    $grado_id = $_GET['grado'];
    $seccion_id = $_GET['seccion'];
    $stmt_estudiantes = $pdo->prepare("
        SELECT e.id, p.nombres, p.apellidos
        FROM estudiantes e
        JOIN personas p ON e.persona_id = p.id
        WHERE e.grado_id = ? AND e.seccion_id = ?
    ");
    $stmt_estudiantes->execute([$grado_id, $seccion_id]);
    $estudiantes = $stmt_estudiantes->fetchAll(PDO::FETCH_ASSOC);
}

// Guardar registros simulados
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_registro'])) {
    foreach ($_POST['asistencia'] as $estudiante_id => $valor) {
        // Aquí normalmente harías INSERT en la tabla asistencias
        // Pero como es ejemplo, solo mostramos un mensaje
        $nombre = $_POST['nombre'][$estudiante_id];
        echo "<p>✅ Registro guardado para $nombre: $valor</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Gestión de Clases - Ejemplo</title>
<link rel="stylesheet" href="../../../CSS/ges_clases.css">
</head>
<body>
<div class="card">
    <h1>Gestión de Clases - Ejemplo</h1>

    <form method="GET">
        <label>Grado:</label>
        <select name="grado" required>
            <option value="">Seleccione un grado</option>
            <?php foreach ($grados as $g): ?>
                <option value="<?= $g['id'] ?>" <?= (isset($_GET['grado']) && $_GET['grado'] == $g['id']) ? 'selected' : '' ?>><?= htmlspecialchars($g['nombre']) ?></option>
            <?php endforeach; ?>
        </select>

        <label>Sección:</label>
        <select name="seccion" required>
            <option value="">Seleccione una sección</option>
            <?php foreach ($secciones as $s): ?>
                <option value="<?= $s['id'] ?>" <?= (isset($_GET['seccion']) && $_GET['seccion'] == $s['id']) ? 'selected' : '' ?>><?= htmlspecialchars($s['nombre']) ?></option>
            <?php endforeach; ?>
        </select>

        <label>Fecha:</label>
        <input type="date" name="fecha" value="<?= isset($_GET['fecha']) ? htmlspecialchars($_GET['fecha']) : date('Y-m-d') ?>">

        <button type="submit">Mostrar Estudiantes</button>
    </form>

    <?php if (isset($_GET['grado'], $_GET['seccion'], $_GET['fecha'])): ?>
        <?php
        // Get grade and section names for display
        $stmt_grado = $pdo->prepare("SELECT nombre FROM grados WHERE id = ?");
        $stmt_grado->execute([$_GET['grado']]);
        $grado_nombre = $stmt_grado->fetchColumn();

        $stmt_seccion = $pdo->prepare("SELECT nombre FROM secciones WHERE id = ?");
        $stmt_seccion->execute([$_GET['seccion']]);
        $seccion_nombre = $stmt_seccion->fetchColumn();
        ?>
        <h2>Lista de Estudiantes - Grado: <?= htmlspecialchars($grado_nombre) ?>, Sección: <?= htmlspecialchars($seccion_nombre) ?> (<?= htmlspecialchars($_GET['fecha']) ?>)</h2>
        <?php if (empty($estudiantes)): ?>
            <p>No se encontraron estudiantes para el grado y sección seleccionados.</p>
        <?php else: ?>
            <form method="POST">
                <table>
                    <thead>
                        <tr>
                            <th>Estudiante</th>
                            <th>Asistencia</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($estudiantes as $e): ?>
                            <tr>
                                <td><?= htmlspecialchars($e['nombres'] . ' ' . $e['apellidos']) ?>
                                    <input type="hidden" name="nombre[<?= $e['id'] ?>]" value="<?= htmlspecialchars($e['nombres'] . ' ' . $e['apellidos']) ?>">
                                </td>
                                <td>
                                    <select name="asistencia[<?= $e['id'] ?>]">
                                        <option value="Presente">Presente</option>
                                        <option value="Ausente">Ausente</option>
                                        <option value="Tarde">Tarde</option>
                                    </select>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <br>
                <button type="submit" name="guardar_registro">Guardar Registro</button>
            </form>
        <?php endif; ?>
    <?php endif; ?>
</div>
</body>
</html>