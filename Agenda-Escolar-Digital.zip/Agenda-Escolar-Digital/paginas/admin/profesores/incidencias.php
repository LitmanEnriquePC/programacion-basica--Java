<?php
session_start();
require __DIR__ . '/../../../sql/conexion.php';

// Verificar autenticación
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php'); // Asumiendo que existe una página de login
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$mensaje = '';
$tipo_mensaje = '';

// Manejar inserción de nueva incidencia
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['action'])) {
    $titulo = trim($_POST['titulo'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $estudiante_id = $_POST['estudiante_id'] ?? null;
    $estado_id = $_POST['estado_id'] ?? 1;
    $fecha_incidencia = date('Y-m-d H:i:s'); // Formato DATETIME para DB

    // Validaciones básicas
    if (empty($titulo) || empty($descripcion)) {
        $mensaje = 'Título y descripción son obligatorios.';
        $tipo_mensaje = 'error';
    } else {
        try {
            // Manejar subida de imagen
            $imagen = null;
            if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
                $upload_dir = __DIR__ . '/../uploads/incidencias/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                $extension = pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION);
                $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
                if (in_array(strtolower($extension), $allowed_types)) {
                    $nombre_archivo = uniqid() . '.' . $extension;
                    $ruta_destino = $upload_dir . $nombre_archivo;
                    if (move_uploaded_file($_FILES['imagen']['tmp_name'], $ruta_destino)) {
                        $imagen = $nombre_archivo;
                    }
                }
            }

            // Insertar en DB
            $stmt = $pdo->prepare("
                INSERT INTO incidencias (titulo, descripcion, estado_id, usuario_reporta_id, estudiante_involucrado_id, imagen, fecha_incidencia) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$titulo, $descripcion, $estado_id, $usuario_id, $estudiante_id, $imagen, $fecha_incidencia]);

            $mensaje = 'Incidencia registrada exitosamente.';
            $tipo_mensaje = 'success';
        } catch (PDOException $e) {
            $mensaje = 'Error al registrar la incidencia.';
            $tipo_mensaje = 'error';
        }
    }
}

// Manejar actualización de estado
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update') {
    $incidencia_id = $_POST['incidencia_id'] ?? 0;
    $nuevo_estado_id = $_POST['estado_id'] ?? 1;

    if ($incidencia_id > 0) {
        try {
            $stmt = $pdo->prepare("UPDATE incidencias SET estado_id = ? WHERE id = ?");
            $stmt->execute([$nuevo_estado_id, $incidencia_id]);

            $mensaje = 'Estado actualizado exitosamente.';
            $tipo_mensaje = 'success';
        } catch (PDOException $e) {
            $mensaje = 'Error al actualizar el estado.';
            $tipo_mensaje = 'error';
        }
    }
}

// Obtener estados para el select
$stmt_estados = $pdo->query("SELECT id, nombre FROM estados_incidencia ORDER BY id");
$estados = $stmt_estados->fetchAll(PDO::FETCH_ASSOC);

// Obtener filtro
$filtro = $_GET['filter'] ?? '';

// Consulta para lista de incidencias
$where = '';
$params = [];
if ($filtro) {
    $where = 'WHERE ei.nombre = ?';
    $params = [$filtro];
}

$stmt_incidencias = $pdo->prepare("
    SELECT 
        i.id,
        i.titulo,
        i.descripcion,
        i.fecha_incidencia,
        i.imagen,
        ei.id as estado_id,
        ei.nombre as estado,
        CONCAT(pp.nombres, ' ', pp.apellidos) as reporter,
        CONCAT(pe.nombres, ' ', pe.apellidos) as estudiante_nombre,
        g.nombre as grado,
        s.nombre as seccion
    FROM incidencias i
    INNER JOIN estados_incidencia ei ON i.estado_id = ei.id
    INNER JOIN usuarios u ON i.usuario_reporta_id = u.id
    INNER JOIN personas pp ON u.persona_id = pp.id
    LEFT JOIN estudiantes e ON i.estudiante_involucrado_id = e.id
    LEFT JOIN personas pe ON e.persona_id = pe.id
    LEFT JOIN grados g ON e.grado_id = g.id
    LEFT JOIN secciones s ON e.seccion_id = s.id
    $where
    ORDER BY i.fecha_registro DESC
");
$stmt_incidencias->execute($params);
$incidencias = $stmt_incidencias->fetchAll(PDO::FETCH_ASSOC);

// Fecha y hora actual en formato 12 horas
$fecha_hora_actual = date('m/d/Y h:i A');
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Incidencias</title>
    <link rel="stylesheet" href="../../../CSS/inc.css">
</head>
<body>
    <h1>Gestión de Incidencias</h1>

    <?php if ($mensaje): ?>
        <div class="mensaje <?php echo $tipo_mensaje; ?>"><?php echo htmlspecialchars($mensaje); ?></div>
    <?php endif; ?>

    <h2>Registrar Nueva Incidencia</h2>
    
    <form method="POST" enctype="multipart/form-data">
        <a href="dashboard.php">
            <button type="button" class="btn">Volver al Dashboard</button>
        </a>
        <div class="form-group">
            <label for="titulo">Título:</label>
            <input type="text" id="titulo" name="titulo" required>
        </div>

        <div class="form-group">
            <label for="descripcion">Descripción:</label>
            <textarea id="descripcion" name="descripcion" required></textarea>
        </div>

        <div class="form-group">
            <label for="dni">DNI del Estudiante Involucrado:</label>
            <input type="text" id="dni" name="dni" maxlength="8" placeholder="Ingrese DNI (8 dígitos)">
            <div id="estudiante-info"></div>
            <input type="hidden" id="estudiante_id" name="estudiante_id">
        </div>

        <div class="form-group">
            <label>Fecha y Hora Actual:</label>
            <p><?php echo $fecha_hora_actual; ?></p>
        </div>

        <div class="form-group">
            <label for="imagen">Imagen (opcional):</label>
            <input type="file" id="imagen" name="imagen" accept="image/*">
        </div>

        <div class="form-group">
            <label for="estado_id">Estado:</label>
            <select id="estado_id" name="estado_id" required>
                <?php foreach ($estados as $estado): ?>
                    <option value="<?php echo $estado['id']; ?>"><?php echo htmlspecialchars($estado['nombre']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit">Crear Incidencia</button>
        
    </form>

    <h2>Lista de Incidencias</h2>
    <div class="filter">
        <label for="filter">Filtrar por Estado:</label>
        <select id="filter" onchange="window.location='?filter=' + this.value">
            <option value="">Todos</option>
            <option value="pendiente" <?php echo ($filtro === 'pendiente') ? 'selected' : ''; ?>>Pendiente</option>
            <option value="en_revision" <?php echo ($filtro === 'en_revision') ? 'selected' : ''; ?>>En revisión</option>
            <option value="resuelta" <?php echo ($filtro === 'resuelta') ? 'selected' : ''; ?>>Resuelta</option>
            <option value="cerrada" <?php echo ($filtro === 'cerrada') ? 'selected' : ''; ?>>Cerrada</option>
        </select>
        
    </div>

    <?php if (empty($incidencias)): ?>
        <p>No hay incidencias para mostrar.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Título</th>
                    <th>Descripción</th>
                    <th>Estudiante</th>
                    <th>Estado</th>
                    <th>Fecha</th>
                    <th>Reportado por</th>
                    <th>Imagen</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($incidencias as $inc): ?>
                    <tr>
                        <td><?php echo $inc['id']; ?></td>
                        <td><?php echo htmlspecialchars($inc['titulo']); ?></td>
                        <td><?php echo htmlspecialchars(substr($inc['descripcion'], 0, 100)) . '...'; ?></td>
                        <td>
                            <?php if ($inc['estudiante_nombre']): ?>
                                <?php echo htmlspecialchars($inc['estudiante_nombre'] . ' - ' . ($inc['grado'] ?? '') . ' ' . ($inc['seccion'] ?? '')); ?>
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($inc['estado']); ?></td>
                        <td><?php echo date('m/d/Y h:i A', strtotime($inc['fecha_incidencia'])); ?></td>
                        <td><?php echo htmlspecialchars($inc['reporter']); ?></td>
                        <td>
                            <?php if ($inc['imagen']): ?>
                                <img src="../uploads/incidencias/<?php echo htmlspecialchars($inc['imagen']); ?>" alt="Imagen">
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="POST" class="update-form">
                                <input type="hidden" name="incidencia_id" value="<?php echo $inc['id']; ?>">
                                <select name="estado_id">
                                    <?php foreach ($estados as $estado): ?>
                                        <option value="<?php echo $estado['id']; ?>" <?php echo ($estado['id'] == $inc['estado_id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($estado['nombre']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" name="action" value="update">Actualizar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <script>
        document.getElementById('dni').addEventListener('input', function() {
            const dni = this.value.trim();
            const infoDiv = document.getElementById('estudiante-info');
            const hiddenId = document.getElementById('estudiante_id');

            if (dni.length === 8 && /^\d{8}$/.test(dni)) {
                fetch(`buscar_estudiante.php?dni=${dni}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            infoDiv.innerHTML = `<strong>${data.nombre}</strong>`;
                            hiddenId.value = data.id;
                        } else {
                            infoDiv.innerHTML = `<span style="color: red;">${data.message}</span>`;
                            hiddenId.value = '';
                        }
                    })
                    .catch(() => {
                        infoDiv.innerHTML = '<span style="color: red;">Error al buscar estudiante</span>';
                        hiddenId.value = '';
                    });
            } else {
                infoDiv.innerHTML = '';
                hiddenId.value = '';
            }
        });
    </script>
</body>
</html>