<?php
session_start();
require __DIR__ . '/../sql/conexion.php';

// Verificar autenticación
if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit();
}

header('Content-Type: application/json');

if (!isset($_GET['dni']) || empty($_GET['dni'])) {
    echo json_encode(['success' => false, 'message' => 'DNI no proporcionado']);
    exit();
}

$dni = trim($_GET['dni']);

// Validar formato de DNI (8 dígitos)
if (!preg_match('/^\d{8}$/', $dni)) {
    echo json_encode(['success' => false, 'message' => 'DNI debe tener 8 dígitos']);
    exit();
}

try {
    $stmt = $pdo->prepare("
        SELECT 
            e.id,
            CONCAT(p.nombres, ' ', p.apellidos) as nombre_completo,
            p.dni,
            g.nombre as grado,
            s.nombre as seccion
        FROM estudiantes e
        INNER JOIN personas p ON e.persona_id = p.id
        INNER JOIN grados g ON e.grado_id = g.id
        INNER JOIN secciones s ON e.seccion_id = s.id
        WHERE p.dni = ?
    ");
    
    $stmt->execute([$dni]);
    $estudiante = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($estudiante) {
        echo json_encode([
            'success' => true,
            'nombre' => $estudiante['nombre_completo'] . ' - ' . $estudiante['grado'] . ' ' . $estudiante['seccion'],
            'id' => $estudiante['id']
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'No se encontró estudiante con ese DNI'
        ]);
    }
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error en el servidor'
    ]);
}
?>