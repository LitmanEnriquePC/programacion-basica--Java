<?php
require_once __DIR__ . '/../../../sql/conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    $dni = $_POST['dni'];
    $correo = $_POST['correo'];
    $password = $_POST['password'];
    $especialidad = isset($_POST['especialidad']) ? $_POST['especialidad'] : null;
    
    try {
        // Verificar si DNI o correo ya existen
        $sql_verificar = "SELECT dni, correo FROM personas WHERE dni = ? OR correo = ?";
        $stmt_verificar = $pdo->prepare($sql_verificar);
        $stmt_verificar->execute([$dni, $correo]);
        $existe = $stmt_verificar->fetch(PDO::FETCH_ASSOC);
        
        if ($existe) {
            if ($existe['dni'] == $dni) {
                $error = "El DNI ya está registrado en el sistema.";
            } else {
                $error = "El correo ya está registrado en el sistema.";
            }
        } else {
            // Iniciar transacción
            $pdo->beginTransaction();
            
            // Insertar en tabla personas
            $sql_persona = "INSERT INTO personas (nombres, apellidos, dni, correo) VALUES (?, ?, ?, ?)";
            $stmt_persona = $pdo->prepare($sql_persona);
            $stmt_persona->execute([$nombres, $apellidos, $dni, $correo]);
            $persona_id = $pdo->lastInsertId();
            
            // Obtener ID del rol profesor
            $sql_rol = "SELECT id FROM roles WHERE nombre_rol = 'profesor'";
            $stmt_rol = $pdo->prepare($sql_rol);
            $stmt_rol->execute();
            $rol_id = $stmt_rol->fetchColumn();
            
            // Hashear contraseña
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            
            // Insertar en tabla usuarios
            $sql_usuario = "INSERT INTO usuarios (persona_id, rol_id, contraseña) VALUES (?, ?, ?)";
            $stmt_usuario = $pdo->prepare($sql_usuario);
            $stmt_usuario->execute([$persona_id, $rol_id, $password_hash]);
            
            // Insertar en tabla profesores
            $sql_profesor = "INSERT INTO profesores (persona_id, especialidad, fecha_contratacion) 
                            VALUES (?, ?, CURDATE())";
            $stmt_profesor = $pdo->prepare($sql_profesor);
            $stmt_profesor->execute([$persona_id, $especialidad]);
            
            // Confirmar transacción
            $pdo->commit();
            
            header("Location: dashboard.php?mensaje=Registro exitoso");
            exit();
        }
        
    } catch(PDOException $e) {
        // Revertir transacción en caso de error
        $pdo->rollBack();
        $error = "Error al registrar el profesor: " . $e->getMessage();
    }
}

// Obtener especialidades (cursos disponibles) para el select
try {
    $sql_cursos = "SELECT id, nombre FROM cursos ORDER BY nombre";
    $stmt_cursos = $pdo->prepare($sql_cursos);
    $stmt_cursos->execute();
    $cursos = $stmt_cursos->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $error = "Error al cargar los cursos.";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro como Profesor</title>
</head>
<body>
    <h2>Registro como Profesor</h2>
    
    <form method="POST" action="registro_profesores.php">
        <label for="nombres">Nombres:</label><br>
        <input type="text" id="nombres" name="nombres" required><br><br>
        
        <label for="apellidos">Apellidos:</label><br>
        <input type="text" id="apellidos" name="apellidos" required><br><br>
        
        <label for="dni">DNI:</label><br>
        <input type="text" id="dni" name="dni" required><br><br>
        
        <label for="correo">Correo:</label><br>
        <input type="email" id="correo" name="correo" required><br><br>
        
        <label for="password">Contraseña:</label><br>
        <input type="password" id="password" name="password" required><br><br>
        
        <input type="submit" value="Registrarse">
    </form>
    
    <br>
    <a href="../../dashboard.php">Volver al Dashboard</a>
    
</body>
</html>