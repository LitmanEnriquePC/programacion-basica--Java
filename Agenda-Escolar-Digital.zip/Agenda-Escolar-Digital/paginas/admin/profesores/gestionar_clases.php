<?php
// gestionar_asistencia.php

require __DIR__ . '/../sql/conexion.php';

// Add 'tardanza' if not exists
$check = $pdo->query("SELECT COUNT(*) FROM estados_asistencia WHERE nombre = 'tardanza'")->fetchColumn();
if ($check == 0) {
    $pdo->query("INSERT INTO estados_asistencia (nombre, descripcion) VALUES ('tardanza', 'Estudiante llegó tarde')");
}

// Fetch estados_asistencia
$estados = $pdo->query("SELECT id, nombre FROM estados_asistencia")->fetchAll(PDO::FETCH_ASSOC);

// Fetch justificado_id
$justificado_id = $pdo->query("SELECT id FROM estados_asistencia WHERE nombre = 'justificado'")->fetchColumn();

// Fetch classes for dropdown
$clases = $pdo->query("
    SELECT cl.id, cu.nombre AS curso, gr.nombre AS grado, se.nombre AS seccion, ds.nombre AS dia
    FROM clases cl
    JOIN cursos cu ON cl.curso_id = cu.id
    JOIN grados gr ON cl.grado_id = gr.id
    JOIN secciones se ON cl.seccion_id = se.id
    JOIN dias_semana ds ON cl.dia_semana_id = ds.id
")->fetchAll(PDO::FETCH_ASSOC);

// Handle POST for saving attendance
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_attendance'])) {
    $clase_id = $_POST['clase_id'];
    $fecha = $_POST['fecha'];

    foreach ($_POST['estado'] as $estudiante_id => $estado_id) {
        $observaciones = isset($_POST['observaciones'][$estudiante_id]) ? $_POST['observaciones'][$estudiante_id] : '';

        // Check if exists
        $stmt = $pdo->prepare("SELECT id FROM asistencias WHERE estudiante_id = ? AND clase_id = ? AND fecha = ?");
        $stmt->execute([$estudiante_id, $clase_id, $fecha]);
        if ($stmt->fetch()) {
            // Update
            $up = $pdo->prepare("UPDATE asistencias SET estado_id = ?, observaciones = ? WHERE estudiante_id = ? AND clase_id = ? AND fecha = ?");
            $up->execute([$estado_id, $observaciones, $estudiante_id, $clase_id, $fecha]);
        } else {
            // Insert
            $ins = $pdo->prepare("INSERT INTO asistencias (estudiante_id, clase_id, fecha, estado_id, observaciones) VALUES (?, ?, ?, ?, ?)");
            $ins->execute([$estudiante_id, $clase_id, $fecha, $estado_id, $observaciones]);
        }
    }

    // Redirect to same page with params
    header("Location: " . $_SERVER['PHP_SELF'] . "?clase_id=$clase_id&fecha=$fecha");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestionar Asistencia</title>
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>Gestionar Asistencia</h1>

    <!-- Form to select class and date -->
    <h2>Seleccionar Clase y Fecha</h2>
    <form method="GET">
        <label>Clase:</label>
        <select name="clase_id" required>
            <?php foreach ($clases as $c): ?>
                <option value="<?php echo $c['id']; ?>" <?php echo (isset($_GET['clase_id']) && $_GET['clase_id'] == $c['id']) ? 'selected' : ''; ?>>
                    <?php echo $c['curso'] . ' - ' . $c['grado'] . ' ' . $c['seccion'] . ' - ' . $c['dia']; ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Fecha:</label>
        <input type="date" name="fecha" value="<?php echo isset($_GET['fecha']) ? $_GET['fecha'] : '2025-10-03'; ?>" required><br><br>

        <button type="submit">Mostrar Estudiantes</button>
    </form>

    <?php if (isset($_GET['clase_id']) && isset($_GET['fecha'])): ?>
        <?php
        $clase_id = $_GET['clase_id'];
        $fecha = $_GET['fecha'];

        // Fetch clase grado and seccion
        $stmt = $pdo->prepare("SELECT grado_id, seccion_id FROM clases WHERE id = ?");
        $stmt->execute([$clase_id]);
        $clase = $stmt->fetch(PDO::FETCH_ASSOC);
        $grado_id = $clase['grado_id'];
        $seccion_id = $clase['seccion_id'];

        // Fetch students
        $stmt = $pdo->prepare("
            SELECT e.id, CONCAT(p.nombres, ' ', p.apellidos) AS nombre
            FROM estudiantes e
            JOIN personas p ON e.persona_id = p.id
            WHERE e.grado_id = ? AND e.seccion_id = ?
            ORDER BY p.apellidos, p.nombres
        ");
        $stmt->execute([$grado_id, $seccion_id]);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Fetch existing attendances
        $attendances = [];
        foreach ($students as $s) {
            $stmt = $pdo->prepare("SELECT estado_id, observaciones FROM asistencias WHERE estudiante_id = ? AND clase_id = ? AND fecha = ?");
            $stmt->execute([$s['id'], $clase_id, $fecha]);
            $att = $stmt->fetch(PDO::FETCH_ASSOC);
            $attendances[$s['id']] = $att ? $att : ['estado_id' => 1, 'observaciones' => ''];
        }
        ?>

        <!-- Form to save attendance -->
        <h2>Lista de Estudiantes (Grado: <?php echo $clases[array_search($clase_id, array_column($clases, 'id'))]['grado']; ?>, Sección: <?php echo $clases[array_search($clase_id, array_column($clases, 'id'))]['seccion']; ?>)</h2>
        <form method="POST">
            <input type="hidden" name="clase_id" value="<?php echo $clase_id; ?>">
            <input type="hidden" name="fecha" value="<?php echo $fecha; ?>">
            <input type="hidden" name="save_attendance" value="1">

            <table>
                <thead>
                    <tr>
                        <th>Estudiante</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $s): ?>
                        <tr>
                            <td><?php echo $s['nombre']; ?></td>
                            <td>
                                <select name="estado[<?php echo $s['id']; ?>]" onchange="toggleMotivo(this, <?php echo $s['id']; ?>)">
                                    <?php foreach ($estados as $e): ?>
                                        <option value="<?php echo $e['id']; ?>" <?php echo $attendances[$s['id']]['estado_id'] == $e['id'] ? 'selected' : ''; ?>>
                                            <?php echo ucfirst($e['nombre']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="text" name="observaciones[<?php echo $s['id']; ?>]" id="motivo_<?php echo $s['id']; ?>" value="<?php echo htmlspecialchars($attendances[$s['id']]['observaciones']); ?>" style="display: <?php echo $attendances[$s['id']]['estado_id'] == $justificado_id ? 'inline' : 'none'; ?>;" placeholder="Motivo">
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <br>
            <button type="submit">Guardar Asistencias</button>
        </form>
    <?php endif; ?>

    <script>
        function toggleMotivo(selectElem, id) {
            var motivo = document.getElementById('motivo_' + id);
            if (selectElem.value == <?php echo $justificado_id; ?>) {
                motivo.style.display = 'inline';
            } else {
                motivo.style.display = 'none';
                motivo.value = '';
            }
        }
    </script>
</body>
</html>