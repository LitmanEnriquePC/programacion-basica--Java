<?php
require_once __DIR__ . '/../../../sql/conexion.php';

$error = '';
$success = '';
$errores_masivos = [];

// PROCESAMIENTO DE REGISTRO INDIVIDUAL
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['registro_individual'])) {
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    $dni = $_POST['dni'];
    $correo = $_POST['correo'];
    $password = $_POST['password'];
    $grado = $_POST['grado'];
    $seccion = $_POST['seccion'];
    
    try {
        // Verificar si DNI o correo ya existen
        $sql_verificar = "SELECT dni, correo FROM personas WHERE dni = ? OR correo = ?";
        $stmt_verificar = $pdo->prepare($sql_verificar);
        $stmt_verificar->execute([$dni, $correo]);
        $existe = $stmt_verificar->fetch(PDO::FETCH_ASSOC);
        
        if ($existe) {
            if ($existe['dni'] == $dni) {
                $error = "El DNI ya está registrado en el sistema.";
            } else {
                $error = "El correo ya está registrado en el sistema.";
            }
        } else {
            // Iniciar transacción
            $pdo->beginTransaction();
            
            // Insertar en tabla personas
            $sql_persona = "INSERT INTO personas (nombres, apellidos, dni, correo) VALUES (?, ?, ?, ?)";
            $stmt_persona = $pdo->prepare($sql_persona);
            $stmt_persona->execute([$nombres, $apellidos, $dni, $correo]);
            $persona_id = $pdo->lastInsertId();
            
            // Obtener ID del rol estudiante
            $sql_rol = "SELECT id FROM roles WHERE nombre_rol = 'estudiante'";
            $stmt_rol = $pdo->prepare($sql_rol);
            $stmt_rol->execute();
            $rol_id = $stmt_rol->fetchColumn();
            
            // Hashear contraseña
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            
            // Insertar en tabla usuarios
            $sql_usuario = "INSERT INTO usuarios (persona_id, rol_id, contraseña) VALUES (?, ?, ?)";
            $stmt_usuario = $pdo->prepare($sql_usuario);
            $stmt_usuario->execute([$persona_id, $rol_id, $password_hash]);
            $usuario_id = $pdo->lastInsertId();
            
            // Obtener IDs de grado y sección
            $sql_grado = "SELECT id FROM grados WHERE nivel_numerico = ?";
            $stmt_grado = $pdo->prepare($sql_grado);
            $stmt_grado->execute([$grado]);
            $grado_id = $stmt_grado->fetchColumn();
            
            $sql_seccion = "SELECT id FROM secciones WHERE nombre = ?";
            $stmt_seccion = $pdo->prepare($sql_seccion);
            $stmt_seccion->execute([$seccion]);
            $seccion_id = $stmt_seccion->fetchColumn();
            
            // Generar código de estudiante
            $codigo_estudiante = 'EST' . date('Y') . str_pad($usuario_id, 3, '0', STR_PAD_LEFT);
            
            // Insertar en tabla estudiantes
            $sql_estudiante = "INSERT INTO estudiantes (persona_id, grado_id, seccion_id, codigo_estudiante, fecha_ingreso) 
                              VALUES (?, ?, ?, ?, CURDATE())";
            $stmt_estudiante = $pdo->prepare($sql_estudiante);
            $stmt_estudiante->execute([$persona_id, $grado_id, $seccion_id, $codigo_estudiante]);
            
            // Confirmar transacción
            $pdo->commit();
            
            $success = "Estudiante registrado exitosamente con código: $codigo_estudiante";
        }
        
    } catch(PDOException $e) {
        // Revertir transacción en caso de error
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $error = "Error al registrar el estudiante: " . $e->getMessage();
    }
}

// PROCESAMIENTO DE REGISTRO MASIVO
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['registro_masivo'])) {
    if (isset($_FILES['archivo_excel']) && $_FILES['archivo_excel']['error'] == 0) {
        $archivo = $_FILES['archivo_excel'];
        $extension = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));
        
        // Validar extensión
        if (!in_array($extension, ['csv', 'xlsx', 'xls'])) {
            $error = "Por favor, sube un archivo CSV o Excel (.csv, .xlsx, .xls)";
        } else {
            try {
                $estudiantes_data = [];
                
                // Procesar archivo CSV
                if ($extension == 'csv') {
                    if (($handle = fopen($archivo['tmp_name'], 'r')) !== FALSE) {
                        // Saltar la primera línea (encabezados)
                        $headers = fgetcsv($handle, 1000, ',');
                        
                        $fila = 1;
                        while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
                            $fila++;
                            
                            // Validar que tenga todas las columnas necesarias
                            if (count($data) >= 7) {
                                $estudiantes_data[] = [
                                    'fila' => $fila,
                                    'nombres' => trim($data[0]),
                                    'apellidos' => trim($data[1]),
                                    'dni' => trim($data[2]),
                                    'correo' => trim($data[3]),
                                    'password' => trim($data[4]),
                                    'grado' => trim($data[5]),
                                    'seccion' => trim($data[6])
                                ];
                            } else {
                                $errores_masivos[] = "Fila $fila: Datos incompletos";
                            }
                        }
                        fclose($handle);
                    }
                }
                // Para archivos Excel (.xlsx, .xls) necesitarías una librería como PHPSpreadsheet
                else {
                    $error = "Para archivos Excel, por favor convierte a CSV o instala la librería PHPSpreadsheet";
                }
                
                // Procesar los estudiantes
                if (!empty($estudiantes_data)) {
                    $registrados = 0;
                    
                    foreach ($estudiantes_data as $estudiante) {
                        try {
                            // Validar datos básicos
                            if (empty($estudiante['nombres']) || empty($estudiante['apellidos']) || 
                                empty($estudiante['dni']) || empty($estudiante['correo']) || 
                                empty($estudiante['password'])) {
                                $errores_masivos[] = "Fila {$estudiante['fila']}: Campos obligatorios vacíos";
                                continue;
                            }
                            
                            // Verificar si DNI o correo ya existen
                            $sql_verificar = "SELECT dni, correo FROM personas WHERE dni = ? OR correo = ?";
                            $stmt_verificar = $pdo->prepare($sql_verificar);
                            $stmt_verificar->execute([$estudiante['dni'], $estudiante['correo']]);
                            $existe = $stmt_verificar->fetch(PDO::FETCH_ASSOC);
                            
                            if ($existe) {
                                if ($existe['dni'] == $estudiante['dni']) {
                                    $errores_masivos[] = "Fila {$estudiante['fila']}: DNI {$estudiante['dni']} ya existe";
                                } else {
                                    $errores_masivos[] = "Fila {$estudiante['fila']}: Correo {$estudiante['correo']} ya existe";
                                }
                                continue;
                            }
                            
                            // Iniciar transacción para cada estudiante
                            $pdo->beginTransaction();
                            
                            // Insertar en tabla personas
                            $sql_persona = "INSERT INTO personas (nombres, apellidos, dni, correo) VALUES (?, ?, ?, ?)";
                            $stmt_persona = $pdo->prepare($sql_persona);
                            $stmt_persona->execute([
                                $estudiante['nombres'], 
                                $estudiante['apellidos'], 
                                $estudiante['dni'], 
                                $estudiante['correo']
                            ]);
                            $persona_id = $pdo->lastInsertId();
                            
                            // Obtener ID del rol estudiante
                            $sql_rol = "SELECT id FROM roles WHERE nombre_rol = 'estudiante'";
                            $stmt_rol = $pdo->prepare($sql_rol);
                            $stmt_rol->execute();
                            $rol_id = $stmt_rol->fetchColumn();
                            
                            // Hashear contraseña
                            $password_hash = password_hash($estudiante['password'], PASSWORD_DEFAULT);
                            
                            // Insertar en tabla usuarios
                            $sql_usuario = "INSERT INTO usuarios (persona_id, rol_id, contraseña) VALUES (?, ?, ?)";
                            $stmt_usuario = $pdo->prepare($sql_usuario);
                            $stmt_usuario->execute([$persona_id, $rol_id, $password_hash]);
                            $usuario_id = $pdo->lastInsertId();
                            
                            // Obtener IDs de grado y sección
                            $sql_grado = "SELECT id FROM grados WHERE nivel_numerico = ?";
                            $stmt_grado = $pdo->prepare($sql_grado);
                            $stmt_grado->execute([$estudiante['grado']]);
                            $grado_id = $stmt_grado->fetchColumn();
                            
                            if (!$grado_id) {
                                throw new Exception("Grado no válido: {$estudiante['grado']}");
                            }
                            
                            $sql_seccion = "SELECT id FROM secciones WHERE nombre = ?";
                            $stmt_seccion = $pdo->prepare($sql_seccion);
                            $stmt_seccion->execute([$estudiante['seccion']]);
                            $seccion_id = $stmt_seccion->fetchColumn();
                            
                            if (!$seccion_id) {
                                throw new Exception("Sección no válida: {$estudiante['seccion']}");
                            }
                            
                            // Generar código de estudiante
                            $codigo_estudiante = 'EST' . date('Y') . str_pad($usuario_id, 3, '0', STR_PAD_LEFT);
                            
                            // Insertar en tabla estudiantes
                            $sql_estudiante = "INSERT INTO estudiantes (persona_id, grado_id, seccion_id, codigo_estudiante, fecha_ingreso) 
                                              VALUES (?, ?, ?, ?, CURDATE())";
                            $stmt_estudiante = $pdo->prepare($sql_estudiante);
                            $stmt_estudiante->execute([$persona_id, $grado_id, $seccion_id, $codigo_estudiante]);
                            
                            // Confirmar transacción
                            $pdo->commit();
                            $registrados++;
                            
                        } catch(Exception $e) {
                            // Revertir transacción en caso de error
                            if ($pdo->inTransaction()) {
                                $pdo->rollBack();
                            }
                            $errores_masivos[] = "Fila {$estudiante['fila']}: " . $e->getMessage();
                        }
                    }
                    
                    if ($registrados > 0) {
                        $success = "Se registraron exitosamente $registrados estudiante(s).";
                    }
                    
                    if (empty($errores_masivos) && $registrados == 0) {
                        $error = "No se pudo registrar ningún estudiante. Revisa el formato del archivo.";
                    }
                }
                
            } catch(Exception $e) {
                $error = "Error al procesar el archivo: " . $e->getMessage();
            }
        }
    } else {
        $error = "Por favor, selecciona un archivo para subir.";
    }
}

// Obtener datos para los selects
try {
    // Obtener grados
    $sql_grados = "SELECT id, nombre, nivel_numerico FROM grados ORDER BY nivel_numerico";
    $stmt_grados = $pdo->prepare($sql_grados);
    $stmt_grados->execute();
    $grados = $stmt_grados->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener secciones
    $sql_secciones = "SELECT id, nombre, descripcion FROM secciones ORDER BY nombre";
    $stmt_secciones = $pdo->prepare($sql_secciones);
    $stmt_secciones->execute();
    $secciones = $stmt_secciones->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    $error = "Error al cargar los datos del formulario.";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Estudiantes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .header h2 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .tabs {
            display: flex;
            background: #f5f5f5;
            border-bottom: 2px solid #ddd;
        }
        
        .tab {
            flex: 1;
            padding: 15px;
            text-align: center;
            cursor: pointer;
            background: #f5f5f5;
            border: none;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s;
            color: #666;
        }
        
        .tab:hover {
            background: #e8e8e8;
        }
        
        .tab.active {
            background: white;
            color: #667eea;
            border-bottom: 3px solid #667eea;
        }
        
        .tab-content {
            display: none;
            padding: 30px;
        }
        
        .tab-content.active {
            display: block;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-weight: 500;
        }
        
        .alert-error {
            background: #fee;
            color: #c33;
            border: 1px solid #fcc;
        }
        
        .alert-success {
            background: #efe;
            color: #3c3;
            border: 1px solid #cfc;
        }
        
        .alert-warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeeba;
        }
        
        .error-list {
            max-height: 200px;
            overflow-y: auto;
            margin-top: 10px;
            padding-left: 20px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
        }
        
        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="file"],
        select {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        input:focus,
        select:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 14px 30px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            width: 100%;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.4);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .file-upload-area {
            border: 3px dashed #ddd;
            border-radius: 8px;
            padding: 40px;
            text-align: center;
            background: #fafafa;
            transition: all 0.3s;
        }
        
        .file-upload-area:hover {
            border-color: #667eea;
            background: #f5f5ff;
        }
        
        .file-upload-area i {
            font-size: 48px;
            color: #667eea;
            margin-bottom: 15px;
        }
        
        .info-box {
            background: #e8eaf6;
            border-left: 4px solid #667eea;
            padding: 15px;
            margin: 20px 0;
            border-radius: 4px;
        }
        
        .info-box h4 {
            color: #667eea;
            margin-bottom: 10px;
        }
        
        .info-box ul {
            margin-left: 20px;
            color: #555;
        }
        
        .info-box li {
            margin-bottom: 5px;
        }
        
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }
        
        .back-link:hover {
            text-decoration: underline;
        }
        
        .download-template {
            background: #4caf50;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            display: inline-block;
            margin: 10px 0;
            font-weight: 600;
        }
        
        .download-template:hover {
            background: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>📚 Registro de Estudiantes</h2>
            <p>Sistema de gestión educativa</p>
        </div>
        
        <?php if ($error): ?>
            <div style="padding: 30px 30px 0 30px;">
                <div class="alert alert-error">
                    ⚠️ <?php echo htmlspecialchars($error); ?>
                </div>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div style="padding: 30px 30px 0 30px;">
                <div class="alert alert-success">
                    ✓ <?php echo htmlspecialchars($success); ?>
                </div>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($errores_masivos)): ?>
            <div style="padding: 30px 30px 0 30px;">
                <div class="alert alert-warning">
                    <strong>⚠️ Se encontraron algunos errores:</strong>
                    <div class="error-list">
                        <ul>
                            <?php foreach ($errores_masivos as $error_msg): ?>
                                <li><?php echo htmlspecialchars($error_msg); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        
        <div class="tabs">
            <button class="tab active" onclick="openTab(event, 'individual')">
                👤 Registro Individual
            </button>
            <button class="tab" onclick="openTab(event, 'masivo')">
                📊 Registro Masivo
            </button>
        </div>
        
        <!-- TAB: REGISTRO INDIVIDUAL -->
        <div id="individual" class="tab-content active">
            <form method="POST" action="registro_estudiantes.php">
                <input type="hidden" name="registro_individual" value="1">
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="nombres">Nombres *</label>
                        <input type="text" id="nombres" name="nombres" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="apellidos">Apellidos *</label>
                        <input type="text" id="apellidos" name="apellidos" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="dni">DNI *</label>
                        <input type="text" id="dni" name="dni" required maxlength="8" pattern="[0-9]{8}">
                    </div>
                    
                    <div class="form-group">
                        <label for="correo">Correo Electrónico *</label>
                        <input type="email" id="correo" name="correo" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="password">Contraseña *</label>
                    <input type="password" id="password" name="password" required minlength="6">
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="grado">Grado *</label>
                        <select id="grado" name="grado" required>
                            <option value="">Selecciona un grado</option>
                            <?php for($i = 1; $i <= 6; $i++): ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?>° Grado</option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="seccion">Sección *</label>
                        <select id="seccion" name="seccion" required>
                            <option value="">Selecciona una sección</option>
                            <option value="A">Sección A</option>
                            <option value="B">Sección B</option>
                            <option value="C">Sección C</option>
                            <option value="D">Sección D</option>
                        </select>
                    </div>
                </div>
                
                <button type="submit" class="btn">Registrar Estudiante</button>
            </form>
        </div>
        
        <!-- TAB: REGISTRO MASIVO -->
        <div id="masivo" class="tab-content">
            <div class="info-box">
                <h4>📋 Formato del archivo CSV</h4>
                <p>El archivo debe contener las siguientes columnas en este orden:</p>
                <ul>
                    <li><strong>Nombres</strong></li>
                    <li><strong>Apellidos</strong></li>
                    <li><strong>DNI</strong> (8 dígitos)</li>
                    <li><strong>Correo</strong></li>
                    <li><strong>Contraseña</strong></li>
                    <li><strong>Grado</strong> (1-6)</li>
                    <li><strong>Sección</strong> (A, B, C, D)</li>
                </ul>
                <a href="generar_plantilla.php" class="download-template" download>
                    ⬇️ Descargar Plantilla CSV
                </a>
            </div>
            
            <form method="POST" action="registro_estudiantes.php" enctype="multipart/form-data">
                <input type="hidden" name="registro_masivo" value="1">
                
                <div class="form-group">
                    <div class="file-upload-area">
                        <div style="font-size: 48px; margin-bottom: 15px;">📁</div>
                        <label for="archivo_excel" style="cursor: pointer; color: #667eea;">
                            <strong>Selecciona un archivo CSV o Excel</strong>
                        </label>
                        <input type="file" id="archivo_excel" name="archivo_excel" 
                               accept=".csv,.xlsx,.xls" required 
                               style="margin-top: 15px;">
                        <p style="color: #999; margin-top: 10px; font-size: 14px;">
                            Formatos aceptados: CSV, XLSX, XLS
                        </p>
                    </div>
                </div>
                
                <button type="submit" class="btn">📤 Subir y Registrar Estudiantes</button>
            </form>
        </div>
        
        <div style="padding: 0 30px 30px 30px; text-align: center;">
            <a href="../../dashboard.php" class="back-link">← Volver al Dashboard</a>
        </div>
    </div>
    
    <script>
        function openTab(evt, tabName) {
            var i, tabcontent, tablinks;
            
            tabcontent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].classList.remove("active");
            }
            
            tablinks = document.getElementsByClassName("tab");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].classList.remove("active");
            }
            
            document.getElementById(tabName).classList.add("active");
            evt.currentTarget.classList.add("active");
        }
        
        // Validación de DNI en tiempo real
        document.getElementById('dni').addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9]/g, '').slice(0, 8);
        });
        
        // Preview del archivo seleccionado
        document.getElementById('archivo_excel').addEventListener('change', function(e) {
            const fileName = e.target.files[0]?.name;
            if (fileName) {
                const preview = document.createElement('p');
                preview.style.marginTop = '10px';
                preview.style.color = '#4caf50';
                preview.style.fontWeight = 'bold';
                preview.textContent = '✓ Archivo seleccionado: ' + fileName;
                
                const existingPreview = this.parentElement.querySelector('p[style*="4caf50"]');
                if (existingPreview) {
                    existingPreview.remove();
                }
                
                this.parentElement.appendChild(preview);
            }
        });
    </script>
</body>
</html>