<?php
session_start();
require_once __DIR__ . '/../sql/conexion.php';

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

$rol = $_SESSION['rol'];
$usuario_id = $_SESSION['usuario_id'];
$nombres = $_SESSION['nombres'];
$apellidos = $_SESSION['apellidos'];

// Definir permisos según rol
$permisos = [
    'admin' => ['ver' => true, 'crear' => true, 'modificar' => true, 'eliminar' => true],
    'profesor' => ['ver' => true, 'crear' => true, 'modificar' => true, 'eliminar' => true],
    'estudiante' => ['ver' => true, 'crear' => false, 'modificar' => false, 'eliminar' => false]
];

$puede_ver = $permisos[$rol]['ver'];
$puede_crear = $permisos[$rol]['crear'];
$puede_modificar = $permisos[$rol]['modificar'];
$puede_eliminar = $permisos[$rol]['eliminar'];

// Obtener información específica según el rol
if ($rol == 'estudiante') {
    try {
        // Obtener información del estudiante
        $sql_estudiante = "SELECT e.codigo_estudiante, g.nombre as grado, s.nombre as seccion, e.fecha_ingreso
                          FROM estudiantes e
                          INNER JOIN grados g ON e.grado_id = g.id
                          INNER JOIN secciones s ON e.seccion_id = s.id
                          INNER JOIN personas p ON e.persona_id = p.id
                          INNER JOIN usuarios u ON u.persona_id = p.id
                          WHERE u.id = ?";
        $stmt = $pdo->prepare($sql_estudiante);
        $stmt->execute([$usuario_id]);
        $info_estudiante = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Obtener clases del estudiante
        $sql_clases_estudiante = "SELECT c.id, cur.nombre as curso, 
                                 CONCAT(p.nombres, ' ', p.apellidos) as profesor,
                                 d.nombre as dia, c.hora_inicio, c.hora_fin, c.aula
                                 FROM clases c
                                 INNER JOIN cursos cur ON c.curso_id = cur.id
                                 INNER JOIN profesores pr ON c.profesor_id = pr.id
                                 INNER JOIN personas p ON pr.persona_id = p.id
                                 INNER JOIN dias_semana d ON c.dia_semana_id = d.id
                                 INNER JOIN estudiantes e ON e.grado_id = c.grado_id AND e.seccion_id = c.seccion_id
                                 INNER JOIN usuarios u ON u.persona_id = e.persona_id
                                 WHERE u.id = ?
                                 ORDER BY d.orden_dia, c.hora_inicio";
        $stmt = $pdo->prepare($sql_clases_estudiante);
        $stmt->execute([$usuario_id]);
        $clases_estudiante = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch(PDOException $e) {
        $error = "Error al cargar información del estudiante: " . $e->getMessage();
    }
} elseif ($rol == 'profesor') {
    try {
        // Obtener información del profesor
        $sql_profesor = "SELECT pr.especialidad, pr.fecha_contratacion
                        FROM profesores pr
                        INNER JOIN personas p ON pr.persona_id = p.id
                        INNER JOIN usuarios u ON u.persona_id = p.id
                        WHERE u.id = ?";
        $stmt = $pdo->prepare($sql_profesor);
        $stmt->execute([$usuario_id]);
        $info_profesor = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Obtener clases que enseña el profesor
        $sql_clases_profesor = "SELECT c.id, cur.nombre as curso, g.nombre as grado, s.nombre as seccion,
                               d.nombre as dia, c.hora_inicio, c.hora_fin, c.aula,
                               COUNT(e.id) as total_estudiantes
                               FROM clases c
                               INNER JOIN cursos cur ON c.curso_id = cur.id
                               INNER JOIN grados g ON c.grado_id = g.id
                               INNER JOIN secciones s ON c.seccion_id = s.id
                               INNER JOIN dias_semana d ON c.dia_semana_id = d.id
                               INNER JOIN profesores pr ON c.profesor_id = pr.id
                               INNER JOIN personas p ON pr.persona_id = p.id
                               INNER JOIN usuarios u ON u.persona_id = p.id
                               LEFT JOIN estudiantes e ON e.grado_id = c.grado_id AND e.seccion_id = c.seccion_id
                               WHERE u.id = ?
                               GROUP BY c.id
                               ORDER BY d.orden_dia, c.hora_inicio";
        $stmt = $pdo->prepare($sql_clases_profesor);
        $stmt->execute([$usuario_id]);
        $clases_profesor = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch(PDOException $e) {
        $error = "Error al cargar información del profesor: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistema Agenda Escolar</title>
    <link rel="stylesheet" href="../CSS/dashboard.css">
</head>
<body>
    <?php if (isset($error)): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="header">
        <h1>Sistema de Agenda Escolar</h1>
        <div class="user-info">
            Bienvenido, <?php echo $nombres . ' ' . $apellidos; ?>
            <span class="role-badge role-<?php echo $rol; ?>">
                <?php echo ucfirst($rol); ?>
            </span>
            <div style="float: right;">
                <a href="logout.php" class="btn btn-danger">Cerrar Sesión</a>
            </div>
        </div>
    </div>

    <!-- Acciones Rápidas -->
    <?php if ($puede_crear): ?>
    <div class="actions">
        <h3>Acciones Rápidas</h3>
        <?php if ($rol == 'admin'): ?>
            <a href="admin/estudiantes/registro_estudiantes.php" class="btn btn-success">Registrar Estudiante</a>
            <a href="admin/profesores/registro_profesores.php" class="btn btn-success">Registrar Profesor</a>
            <a href="admin/gestion/gestionar_clases.php" class="btn btn-primary">Gestionar Clases</a>
            <a href="admin/gestion/gestionar_asistencias.php" class="btn btn-primary">Gestionar Asistencias</a>
            <a href="admin/profesores/incidencias.php" class="btn btn-success">Incidencias</a>
        <?php elseif ($rol == 'profesor'): ?>
            <a href="tomar_asistencia.php" class="btn btn-primary">Tomar Asistencia</a>
            <a href="mis_clases.php" class="btn btn-primary">Mis Clases</a>
            <a href="crear_clase.php" class="btn btn-success">Crear Clase</a>
            <a href="admin/profesores/incidencias.php" class="btn btn-success">Incidencias</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <div class="info-grid">
        <!-- Información específica del rol -->
        <?php if ($rol == 'estudiante' && isset($info_estudiante)): ?>
        <div class="section">
            <h3>Mi Información</h3>
            <p><strong>Código:</strong> <?php echo $info_estudiante['codigo_estudiante']; ?></p>
            <p><strong>Grado:</strong> <?php echo $info_estudiante['grado']; ?></p>
            <p><strong>Sección:</strong> <?php echo $info_estudiante['seccion']; ?></p>
            <p><strong>Fecha de Ingreso:</strong> <?php echo date('d/m/Y', strtotime($info_estudiante['fecha_ingreso'])); ?></p>
        </div>

        <div class="section">
            <h3>Mi Horario de Clases</h3>
            <?php if (!empty($clases_estudiante)): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Curso</th>
                            <th>Día</th>
                            <th>Hora</th>
                            <th>Aula</th>
                            <th>Profesor</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($clases_estudiante as $clase): ?>
                        <tr>
                            <td><?php echo $clase['curso']; ?></td>
                            <td><?php echo $clase['dia']; ?></td>
                            <td><?php echo date('H:i', strtotime($clase['hora_inicio'])) . ' - ' . date('H:i', strtotime($clase['hora_fin'])); ?></td>
                            <td><?php echo $clase['aula']; ?></td>
                            <td><?php echo $clase['profesor']; ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No tienes clases asignadas.</p>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if ($rol == 'profesor' && isset($info_profesor)): ?>
        <div class="section">
            <h3>Mi Información</h3>
            <p><strong>Especialidad:</strong> <?php echo $info_profesor['especialidad'] ?: 'No especificada'; ?></p>
            <p><strong>Fecha de Ingreso:</strong> <?php echo date('d/m/Y', strtotime($info_profesor['fecha_contratacion'])); ?></p>
        </div>

        <div class="section">
            <h3>Mis Clases</h3>
            <?php if (!empty($clases_profesor)): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Curso</th>
                            <th>Grado</th>
                            <th>Sección</th>
                            <th>Día</th>
                            <th>Hora</th>
                            <th>Aula</th>
                            <th>Estudiantes</th>
                            <?php if ($puede_modificar): ?>
                            <th>Acciones</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($clases_profesor as $clase): ?>
                        <tr>
                            <td><?php echo $clase['curso']; ?></td>
                            <td><?php echo $clase['grado']; ?></td>
                            <td><?php echo $clase['seccion']; ?></td>
                            <td><?php echo $clase['dia']; ?></td>
                            <td><?php echo date('H:i', strtotime($clase['hora_inicio'])) . ' - ' . date('H:i', strtotime($clase['hora_fin'])); ?></td>
                            <td><?php echo $clase['aula']; ?></td>
                            <td><?php echo $clase['total_estudiantes']; ?></td>
                            <?php if ($puede_modificar): ?>
                            <td>
                                <a href="tomar_asistencia.php?clase=<?php echo $clase['id']; ?>" class="btn btn-success">Asistencia</a>
                                <a href="editar_clase.php?id=<?php echo $clase['id']; ?>" class="btn btn-warning">Editar</a>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No tienes clases asignadas.</p>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>