<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Contraseña - Agenda Escolar</title>
    <link rel="stylesheet" href="../../CSS/form_recuperacion.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔐 Recuperar Contraseña</h1>
            <p>Sistema de Agenda Escolar - IEP 70035 Puno</p>
        </div>

        <div class="content">
            <div id="alertBox" class="alert"></div>
            <div id="loadingBox" class="loading">
                <div class="spinner"></div>
                <p>Procesando...</p>
            </div>

            <!-- PASO 1: Solicitar DNI -->
            <div id="step1" class="step active">
                <div class="info-box">
                    <strong>🔍 Ingresa tu DNI</strong>
                    <p style="margin-top: 10px;">Ingresa tu número de DNI para verificar tu identidad y enviarte un código de recuperación.</p>
                </div>

                <form id="formSolicitarDNI">
                    <div class="form-group">
                        <label for="dni">Número de DNI</label>
                        <input type="text" id="dni" name="dni" 
                               placeholder="Ingresa tu DNI de 8 dígitos" 
                               maxlength="8" 
                               pattern="[0-9]{8}" 
                               required>
                        <div class="password-requirements">
                            El DNI debe tener exactamente 8 dígitos
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        Verificar DNI
                    </button>
                </form>

                <div class="back-link">
                    <a href="../../login.php">← Volver al inicio de sesión</a>
                </div>
            </div>

            <!-- PASO 1.5: Confirmar envío de código -->
            <div id="step1-5" class="step">
                <div class="info-box">
                    <strong>📧 Confirmación de Envío</strong>
                    <p style="margin-top: 10px;">Hemos encontrado tu cuenta y enviado un código de verificación.</p>
                </div>

                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <p style="margin-bottom: 10px;">El código de verificación ha sido enviado a:</p>
                    <div style="font-size: 18px; font-weight: bold; color: #2563eb; text-align: center; padding: 15px; background: white; border-radius: 5px; margin-top: 10px;">
                        <span id="correoMostrado"></span>
                    </div>
                    <p style="margin-top: 15px; color: #6c757d; font-size: 14px; text-align: center;">
                        Si este no es tu correo, contacta al administrador del sistema.
                    </p>
                </div>

                <button type="button" class="btn btn-primary" onclick="irAPaso(2)">
                    Continuar e Ingresar Código
                </button>

                <button type="button" class="btn btn-secondary" onclick="volverPaso1()">
                    Intentar con otro DNI
                </button>
            </div>

            <!-- PASO 2: Verificar código -->
            <div id="step2" class="step">
                <div class="info-box">
                    <strong>✉️ Revisa tu correo</strong>
                    <p style="margin-top: 10px;">Hemos enviado un código de 6 dígitos a tu correo electrónico. El código es válido por 30 minutos.</p>
                    <ul>
                        <li>Tienes 3 intentos para ingresar el código correcto</li>
                        <li>Si no recibes el correo, revisa tu carpeta de spam</li>
                    </ul>
                </div>

                <form id="formVerificar">
                    <div class="form-group">
                        <label for="codigo">Código de Verificación</label>
                        <input type="text" id="codigo" name="codigo" 
                               class="code-input" maxlength="6" 
                               placeholder="000000" required 
                               pattern="[0-9]{6}">
                        <div class="password-requirements">
                            Ingresa el código de 6 dígitos que recibiste por correo
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        Verificar Código
                    </button>

                    <button type="button" class="btn btn-secondary" onclick="volverPaso1()">
                        Solicitar Nuevo Código
                    </button>
                </form>
            </div>

            <!-- PASO 3: Nueva contraseña -->
            <div id="step3" class="step">
                <div class="info-box">
                    <strong>🔒 Nueva Contraseña</strong>
                    <p style="margin-top: 10px;">Elige una contraseña segura para tu cuenta.</p>
                </div>

                <form id="formRestablecer">
                    <div class="form-group">
                        <label for="nueva_password">Nueva Contraseña</label>
                        <input type="password" id="nueva_password" name="nueva_password" 
                               placeholder="Mínimo 6 caracteres" required minlength="6">
                        <div class="password-requirements">
                            La contraseña debe tener al menos 6 caracteres
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="confirmar_password">Confirmar Contraseña</label>
                        <input type="password" id="confirmar_password" name="confirmar_password" 
                               placeholder="Repite tu contraseña" required minlength="6">
                    </div>

                    <button type="submit" class="btn btn-primary">
                        Restablecer Contraseña
                    </button>
                </form>
            </div>

            <!-- PASO 4: Éxito -->
            <div id="step4" class="step">
                <div style="text-align: center; padding: 40px 0;">
                    <div style="font-size: 72px; margin-bottom: 20px;">✅</div>
                    <h2 style="color: #28a745; margin-bottom: 15px;">¡Contraseña Actualizada!</h2>
                    <p style="color: #666; margin-bottom: 30px;">
                        Tu contraseña ha sido cambiada exitosamente.<br>
                        Ya puedes iniciar sesión con tu nueva contraseña.
                    </p>
                    <a href="../login.php" class="btn">
                        Ir al Inicio de Sesión
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script>
        let correoUsuario = '';

        // Función para mostrar alertas
        function mostrarAlerta(mensaje, tipo) {
            const alertBox = document.getElementById('alertBox');
            alertBox.className = `alert alert-${tipo} show`;
            alertBox.textContent = mensaje;
            
            setTimeout(() => {
                alertBox.classList.remove('show');
            }, 5000);
        }

        // Función para mostrar/ocultar loading
        function toggleLoading(show) {
            const loadingBox = document.getElementById('loadingBox');
            const forms = document.querySelectorAll('form');
            
            if (show) {
                loadingBox.classList.add('show');
                forms.forEach(form => {
                    const btn = form.querySelector('button[type="submit"]');
                    if (btn) btn.disabled = true;
                });
            } else {
                loadingBox.classList.remove('show');
                forms.forEach(form => {
                    const btn = form.querySelector('button[type="submit"]');
                    if (btn) btn.disabled = false;
                });
            }
        }

        // Cambiar de paso
        function irAPaso(numeroPaso) {
            document.querySelectorAll('.step').forEach(step => {
                step.classList.remove('active');
            });
            
            // Manejar el paso 1.5
            if (numeroPaso === 1.5) {
                document.getElementById('step1-5').classList.add('active');
            } else {
                document.getElementById(`step${numeroPaso}`).classList.add('active');
            }
        }

        function volverPaso1() {
            irAPaso(1);
            document.getElementById('formSolicitarDNI').reset();
            correoUsuario = '';
        }

        // Función para ofuscar correo
        function ofuscarCorreo(correo) {
            const partes = correo.split('@');
            const nombre = partes[0];
            const dominio = partes[1];
            
            let nombreOfuscado = '';
            if (nombre.length <= 3) {
                nombreOfuscado = nombre.charAt(0) + '*'.repeat(nombre.length - 1);
            } else {
                nombreOfuscado = nombre.substring(0, 2) + '*'.repeat(nombre.length - 4) + nombre.substring(nombre.length - 2);
            }
            
            return nombreOfuscado + '@' + dominio;
        }

        // PASO 1: Verificar DNI y solicitar código
        document.getElementById('formSolicitarDNI').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const dni = document.getElementById('dni').value;
            
            if (!/^\d{8}$/.test(dni)) {
                mostrarAlerta('El DNI debe tener exactamente 8 dígitos', 'error');
                return;
            }
            
            toggleLoading(true);

            try {
                const response = await fetch('recuperar_contraseña.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `dni=${encodeURIComponent(dni)}`
                });

                const data = await response.json();
                
                toggleLoading(false);

                if (data.success) {
                    correoUsuario = data.correo_completo; // Guardar el correo completo para uso interno
                    
                    // Mostrar el correo ofuscado
                    document.getElementById('correoMostrado').textContent = data.correo_ofuscado;
                    
                    mostrarAlerta('Código enviado exitosamente', 'success');
                    setTimeout(() => {
                        irAPaso(1.5);
                    }, 1500);
                } else {
                    mostrarAlerta(data.message, 'error');
                }
            } catch (error) {
                toggleLoading(false);
                mostrarAlerta('Error de conexión. Intenta nuevamente.', 'error');
                console.error('Error:', error);
            }
        });

        // Solo permitir números en el DNI
        document.getElementById('dni').addEventListener('input', (e) => {
            e.target.value = e.target.value.replace(/[^0-9]/g, '');
        });

        // PASO 2: Verificar código
        document.getElementById('formVerificar').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const codigo = document.getElementById('codigo').value;
            
            if (!/^\d{6}$/.test(codigo)) {
                mostrarAlerta('El código debe tener 6 dígitos numéricos', 'error');
                return;
            }
            
            toggleLoading(true);

            try {
                const response = await fetch('verificar_codigo.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `accion=verificar&correo=${encodeURIComponent(correoUsuario)}&codigo=${encodeURIComponent(codigo)}`
                });

                const data = await response.json();
                
                toggleLoading(false);

                if (data.success) {
                    mostrarAlerta(data.message, 'success');
                    setTimeout(() => {
                        irAPaso(3);
                    }, 1500);
                } else {
                    mostrarAlerta(data.message, 'error');
                    if (data.intentos_restantes === 0) {
                        setTimeout(() => {
                            volverPaso1();
                        }, 3000);
                    }
                }
            } catch (error) {
                toggleLoading(false);
                mostrarAlerta('Error de conexión. Intenta nuevamente.', 'error');
                console.error('Error:', error);
            }
        });

        // Solo permitir números en el código
        document.getElementById('codigo').addEventListener('input', (e) => {
            e.target.value = e.target.value.replace(/[^0-9]/g, '');
        });

        // PASO 3: Restablecer contraseña
        document.getElementById('formRestablecer').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const nueva_password = document.getElementById('nueva_password').value;
            const confirmar_password = document.getElementById('confirmar_password').value;
            
            if (nueva_password !== confirmar_password) {
                mostrarAlerta('Las contraseñas no coinciden', 'error');
                return;
            }

            if (nueva_password.length < 6) {
                mostrarAlerta('La contraseña debe tener al menos 6 caracteres', 'error');
                return;
            }
            
            toggleLoading(true);

            try {
                const response = await fetch('verificar_codigo.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `accion=restablecer&nueva_password=${encodeURIComponent(nueva_password)}&confirmar_password=${encodeURIComponent(confirmar_password)}`
                });

                const data = await response.json();
                
                toggleLoading(false);

                if (data.success) {
                    mostrarAlerta(data.message, 'success');
                    setTimeout(() => {
                        irAPaso(4);
                    }, 1500);
                } else {
                    mostrarAlerta(data.message, 'error');
                    if (data.message.includes('Sesión')) {
                        setTimeout(() => {
                            volverPaso1();
                        }, 3000);
                    }
                }
            } catch (error) {
                toggleLoading(false);
                mostrarAlerta('Error de conexión. Intenta nuevamente.', 'error');
                console.error('Error:', error);
            }
        });

        // Validar que las contraseñas coincidan en tiempo real
        document.getElementById('confirmar_password').addEventListener('input', (e) => {
            const nueva = document.getElementById('nueva_password').value;
            const confirmar = e.target.value;
            
            if (confirmar && nueva !== confirmar) {
                e.target.style.borderColor = '#dc3545';
            } else {
                e.target.style.borderColor = '#e0e0e0';
            }
        });
    </script>
</body>
</html>