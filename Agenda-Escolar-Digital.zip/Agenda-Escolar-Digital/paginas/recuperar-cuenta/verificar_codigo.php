<?php
// verificar_codigo.php
require __DIR__ . '/../../sql/conexion.php';
session_start();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

$accion = $_POST['accion'] ?? '';

// ===== VERIFICAR CÓDIGO =====
if ($accion === 'verificar') {
    $correo = filter_input(INPUT_POST, 'correo', FILTER_SANITIZE_EMAIL);
    $codigo = trim($_POST['codigo'] ?? '');

    if (!filter_var($correo, FILTER_VALIDATE_EMAIL) || empty($codigo)) {
        echo json_encode(['success' => false, 'message' => 'Datos inválidos']);
        exit;
    }

    try {
        // Obtener el código más reciente no usado del usuario
        $stmt = $pdo->prepare("
            SELECT rc.id, rc.usuario_id, rc.codigo_unico, rc.fecha_expiracion, rc.usado,
                   p.correo
            FROM recuperar_contraseña rc
            INNER JOIN usuarios u ON rc.usuario_id = u.id
            INNER JOIN personas p ON u.persona_id = p.id
            WHERE p.correo = ? AND rc.usado = FALSE
            ORDER BY rc.fecha_solicitud DESC
            LIMIT 1
        ");
        $stmt->execute([$correo]);
        $recuperacion = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$recuperacion) {
            echo json_encode(['success' => false, 'message' => 'No se encontró ninguna solicitud de recuperación activa']);
            exit;
        }

        // Verificar si el código ha expirado
        if (strtotime($recuperacion['fecha_expiracion']) < time()) {
            // Marcar como usado
            $stmt = $pdo->prepare("UPDATE recuperar_contraseña SET usado = TRUE WHERE id = ?");
            $stmt->execute([$recuperacion['id']]);
            
            echo json_encode(['success' => false, 'message' => 'El código ha expirado. Solicita uno nuevo.']);
            exit;
        }

        // Verificar intentos (máximo 3)
        $intentos_key = 'intentos_' . $recuperacion['id'];
        if (!isset($_SESSION[$intentos_key])) {
            $_SESSION[$intentos_key] = 0;
        }

        if ($_SESSION[$intentos_key] >= 3) {
            // Marcar como usado después de 3 intentos fallidos
            $stmt = $pdo->prepare("UPDATE recuperar_contraseña SET usado = TRUE WHERE id = ?");
            $stmt->execute([$recuperacion['id']]);
            
            unset($_SESSION[$intentos_key]);
            echo json_encode(['success' => false, 'message' => 'Has superado el número máximo de intentos. Solicita un nuevo código.']);
            exit;
        }

        // Verificar si el código coincide
        if ($codigo !== $recuperacion['codigo_unico']) {
            $_SESSION[$intentos_key]++;
            $intentos_restantes = 3 - $_SESSION[$intentos_key];
            
            echo json_encode([
                'success' => false, 
                'message' => "Código incorrecto. Te quedan {$intentos_restantes} intento(s).",
                'intentos_restantes' => $intentos_restantes
            ]);
            exit;
        }

        // Código válido - guardar en sesión para restablecer contraseña
        $_SESSION['recuperacion_valida'] = [
            'id' => $recuperacion['id'],
            'usuario_id' => $recuperacion['usuario_id'],
            'correo' => $correo,
            'timestamp' => time()
        ];

        unset($_SESSION[$intentos_key]);

        echo json_encode([
            'success' => true, 
            'message' => '✓ Código verificado correctamente. Ahora puedes cambiar tu contraseña.',
            'codigo_valido' => true
        ]);

    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error en la base de datos: ' . $e->getMessage()]);
    }
}

// ===== RESTABLECER CONTRASEÑA =====
elseif ($accion === 'restablecer') {
    $nueva_password = $_POST['nueva_password'] ?? '';
    $confirmar_password = $_POST['confirmar_password'] ?? '';

    // Verificar que hay una sesión válida
    if (!isset($_SESSION['recuperacion_valida'])) {
        echo json_encode(['success' => false, 'message' => 'Sesión inválida. Verifica el código nuevamente.']);
        exit;
    }

    $recuperacion_data = $_SESSION['recuperacion_valida'];

    // Verificar que no hayan pasado más de 10 minutos desde la verificación
    if (time() - $recuperacion_data['timestamp'] > 600) {
        unset($_SESSION['recuperacion_valida']);
        echo json_encode(['success' => false, 'message' => 'La sesión ha expirado. Verifica el código nuevamente.']);
        exit;
    }

    // Validar contraseñas
    if (empty($nueva_password) || empty($confirmar_password)) {
        echo json_encode(['success' => false, 'message' => 'Debes completar ambos campos de contraseña']);
        exit;
    }

    if ($nueva_password !== $confirmar_password) {
        echo json_encode(['success' => false, 'message' => 'Las contraseñas no coinciden']);
        exit;
    }

    if (strlen($nueva_password) < 6) {
        echo json_encode(['success' => false, 'message' => 'La contraseña debe tener al menos 6 caracteres']);
        exit;
    }

    try {
        // Hash de la nueva contraseña
        $password_hash = password_hash($nueva_password, PASSWORD_BCRYPT, ['cost' => 12]);

        // Actualizar contraseña
        $stmt = $pdo->prepare("UPDATE usuarios SET contraseña = ? WHERE id = ?");
        $stmt->execute([$password_hash, $recuperacion_data['usuario_id']]);

        // Marcar el código como usado
        $stmt = $pdo->prepare("UPDATE recuperar_contraseña SET usado = TRUE WHERE id = ?");
        $stmt->execute([$recuperacion_data['id']]);

        // Limpiar sesión
        unset($_SESSION['recuperacion_valida']);

        echo json_encode([
            'success' => true, 
            'message' => '✓ Contraseña actualizada correctamente. Ya puedes iniciar sesión con tu nueva contraseña.'
        ]);

    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error al actualizar la contraseña: ' . $e->getMessage()]);
    }
}

else {
    echo json_encode(['success' => false, 'message' => 'Acción no válida']);
}
?>