<?php
// recuperar_contraseña.php
require __DIR__ . '/../../sql/conexion.php';
require __DIR__ . '/../../Libs/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

// Obtener el DNI del POST
$dni = trim($_POST['dni'] ?? '');

// Validar que el DNI tenga 8 dígitos
if (!preg_match('/^\d{8}$/', $dni)) {
    echo json_encode(['success' => false, 'message' => 'El DNI debe tener exactamente 8 dígitos']);
    exit;
}

try {
    // Verificar si el DNI existe y obtener el usuario con su correo
    $stmt = $pdo->prepare("
        SELECT u.id, p.nombres, p.apellidos, p.correo 
        FROM usuarios u
        INNER JOIN personas p ON u.persona_id = p.id
        WHERE p.dni = ? AND u.activo = TRUE
    ");
    $stmt->execute([$dni]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        echo json_encode(['success' => false, 'message' => 'No se encontró ninguna cuenta asociada a este DNI']);
        exit;
    }

    $correo = $usuario['correo'];

    // Generar código de 6 dígitos
    $codigo = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
    
    // Calcular fecha de expiración (30 minutos)
    $fecha_expiracion = date('Y-m-d H:i:s', strtotime('+30 minutes'));

    // Invalidar códigos anteriores no usados
    $stmt = $pdo->prepare("
        UPDATE recuperar_contraseña 
        SET usado = TRUE 
        WHERE usuario_id = ? AND usado = FALSE
    ");
    $stmt->execute([$usuario['id']]);

    // Insertar nuevo código
    $stmt = $pdo->prepare("
        INSERT INTO recuperar_contraseña (usuario_id, codigo_unico, fecha_expiracion) 
        VALUES (?, ?, ?)
    ");
    $stmt->execute([$usuario['id'], $codigo, $fecha_expiracion]);

    // Configurar PHPMailer
    $mail = new PHPMailer(true);

    try {
        // Configuración del servidor SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'tecnologias@iep70035puno.edu.pe';
        $mail->Password = 'smmywmdbqwbkhchq';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->CharSet = 'UTF-8';

        // Remitente y destinatario
        $mail->setFrom('tecnologias@iep70035puno.edu.pe', 'IEP 70035 Puno - Sistema de Agenda Escolar');
        $mail->addAddress($correo, $usuario['nombres'] . ' ' . $usuario['apellidos']);

        // Contenido del correo
        $mail->isHTML(true);
        $mail->Subject = 'Código de Recuperación de Contraseña - Agenda Escolar';
        
        $mail->Body = "
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #4CAF50; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
                .content { background-color: #f9f9f9; padding: 30px; border: 1px solid #ddd; }
                .code { background-color: #fff; border: 2px dashed #4CAF50; padding: 20px; text-align: center; font-size: 32px; font-weight: bold; letter-spacing: 8px; color: #4CAF50; margin: 20px 0; }
                .warning { background-color: #fff3cd; border-left: 4px solid #ffc107; padding: 12px; margin: 20px 0; }
                .footer { text-align: center; color: #777; font-size: 12px; margin-top: 20px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>🔐 Recuperación de Contraseña</h2>
                </div>
                <div class='content'>
                    <p>Hola <strong>{$usuario['nombres']} {$usuario['apellidos']}</strong>,</p>
                    <p>Recibimos una solicitud para restablecer la contraseña de tu cuenta en el Sistema de Agenda Escolar.</p>
                    
                    <p>Tu código de verificación es:</p>
                    <div class='code'>{$codigo}</div>
                    
                    <div class='warning'>
                        <strong>⚠️ Importante:</strong>
                        <ul style='margin: 10px 0;'>
                            <li>Este código expirará en <strong>30 minutos</strong></li>
                            <li>Solo puedes intentar verificarlo <strong>3 veces</strong></li>
                            <li>Si no solicitaste este cambio, ignora este correo</li>
                        </ul>
                    </div>
                    
                    <p>Ingresa este código en la página de recuperación para continuar con el proceso.</p>
                    <p style='margin-top: 30px;'>Saludos,<br><strong>Equipo de Tecnologías - IEP 70035 Puno</strong></p>
                </div>
                <div class='footer'>
                    <p>Este es un correo automático, por favor no responder.</p>
                    <p>&copy; 2025 IEP 70035 Puno - Sistema de Agenda Escolar Digital</p>
                </div>
            </div>
        </body>
        </html>
        ";

        $mail->AltBody = "Hola {$usuario['nombres']} {$usuario['apellidos']},\n\n"
                       . "Tu código de recuperación es: {$codigo}\n\n"
                       . "Este código expirará en 30 minutos y solo puedes intentar verificarlo 3 veces.\n\n"
                       . "Si no solicitaste este cambio, ignora este correo.\n\n"
                       . "Saludos,\nEquipo de Tecnologías - IEP 70035 Puno";

        $mail->send();

        // Ofuscar el correo para mostrarlo al usuario
        $partes = explode('@', $correo);
        $nombre = $partes[0];
        $dominio = $partes[1];
        
        if (strlen($nombre) <= 3) {
            $nombre_ofuscado = $nombre[0] . str_repeat('*', strlen($nombre) - 1);
        } else {
            $nombre_ofuscado = substr($nombre, 0, 2) . str_repeat('*', strlen($nombre) - 4) . substr($nombre, -2);
        }
        
        $correo_ofuscado = $nombre_ofuscado . '@' . $dominio;

        echo json_encode([
            'success' => true, 
            'message' => 'Código enviado correctamente. Revisa tu correo electrónico.',
            'correo_ofuscado' => $correo_ofuscado,
            'correo_completo' => $correo, // Para uso interno del frontend
            'expiracion' => 30 // minutos
        ]);

    } catch (Exception $e) {
        echo json_encode([
            'success' => false, 
            'message' => 'Error al enviar el correo: ' . $mail->ErrorInfo
        ]);
    }

} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'Error en la base de datos: ' . $e->getMessage()
    ]);
}
?>