<?php
// index.php - Redirige al login principal
header("Location: paginas/login.php");
exit();
?>