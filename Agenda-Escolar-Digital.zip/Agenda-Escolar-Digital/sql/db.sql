-- Creación de la base de datos
CREATE DATABASE agenda_escolar;



-- Tabla personas (entidad principal para datos comunes)
CREATE TABLE personas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombres VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    dni VARCHAR(8) UNIQUE NOT NULL,
    correo VARCHAR(100) UNIQUE NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla roles (normalizada para evitar dependencias transitivas)
CREATE TABLE roles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre_rol VARCHAR(20) UNIQUE NOT NULL,
    descripcion VARCHAR(100)
);

-- Tabla usuarios (sin redundancia de datos personales)
CREATE TABLE usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    persona_id INT NOT NULL,
    rol_id INT NOT NULL,
    contraseña VARCHAR(255) NOT NULL,
    activo BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (persona_id) REFERENCES personas(id) ON DELETE CASCADE,
    FOREIGN KEY (rol_id) REFERENCES roles(id) ON DELETE RESTRICT,
    UNIQUE KEY unique_persona_rol (persona_id, rol_id)
);

-- Tabla grados (normalizada)
CREATE TABLE grados (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(10) UNIQUE NOT NULL,
    nivel_numerico INT UNIQUE NOT NULL
);

-- Tabla secciones (normalizada)
CREATE TABLE secciones (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(5) UNIQUE NOT NULL,
    descripcion VARCHAR(50)
);

-- Tabla cursos (normalizada para evitar redundancia)
CREATE TABLE cursos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) UNIQUE NOT NULL
);

-- Tabla dias_semana (normalizada)
CREATE TABLE dias_semana (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(15) UNIQUE NOT NULL,
    orden_dia INT UNIQUE NOT NULL
);

-- Tabla estudiantes (solo información específica de estudiantes)
CREATE TABLE estudiantes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    persona_id INT NOT NULL,
    grado_id INT NOT NULL,
    seccion_id INT NOT NULL,
    codigo_estudiante VARCHAR(20) UNIQUE,
    fecha_ingreso DATE,
    FOREIGN KEY (persona_id) REFERENCES personas(id) ON DELETE CASCADE,
    FOREIGN KEY (grado_id) REFERENCES grados(id) ON DELETE RESTRICT,
    FOREIGN KEY (seccion_id) REFERENCES secciones(id) ON DELETE RESTRICT
);

-- Tabla profesores (solo información específica de profesores)
CREATE TABLE profesores (
    id INT PRIMARY KEY AUTO_INCREMENT,
    persona_id INT NOT NULL,
    especialidad VARCHAR(100),
    fecha_contratacion DATE,
    FOREIGN KEY (persona_id) REFERENCES personas(id) ON DELETE CASCADE
);

-- Tabla clases (normalizada para horarios)
CREATE TABLE clases (
    id INT PRIMARY KEY AUTO_INCREMENT,
    curso_id INT NOT NULL,
    profesor_id INT NOT NULL,
    grado_id INT NOT NULL,
    seccion_id INT NOT NULL,
    dia_semana_id INT NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    aula VARCHAR(50),
    FOREIGN KEY (curso_id) REFERENCES cursos(id) ON DELETE RESTRICT,
    FOREIGN KEY (profesor_id) REFERENCES profesores(id) ON DELETE CASCADE,
    FOREIGN KEY (grado_id) REFERENCES grados(id) ON DELETE RESTRICT,
    FOREIGN KEY (seccion_id) REFERENCES secciones(id) ON DELETE RESTRICT,
    FOREIGN KEY (dia_semana_id) REFERENCES dias_semana(id) ON DELETE RESTRICT
);

-- Tabla estados_asistencia (normalizada)
CREATE TABLE estados_asistencia (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(20) UNIQUE NOT NULL,
    descripcion VARCHAR(100)
);

-- Tabla asistencias (registro de asistencias normalizado)
CREATE TABLE asistencias (
    id INT PRIMARY KEY AUTO_INCREMENT,
    estudiante_id INT NOT NULL,
    clase_id INT NOT NULL,
    fecha DATE NOT NULL,
    estado_id INT NOT NULL DEFAULT 1,
    observaciones TEXT,
    FOREIGN KEY (estudiante_id) REFERENCES estudiantes(id) ON DELETE CASCADE,
    FOREIGN KEY (clase_id) REFERENCES clases(id) ON DELETE CASCADE,
    FOREIGN KEY (estado_id) REFERENCES estados_asistencia(id) ON DELETE RESTRICT
);

-- Tabla recuperar_contraseña (normalizada para recuperación segura)
CREATE TABLE recuperar_contraseña (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    codigo_unico VARCHAR(50) UNIQUE NOT NULL,
    fecha_solicitud TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_expiracion DATETIME NOT NULL,
    usado BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabla estados_incidencia (normalizada)
CREATE TABLE estados_incidencia (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(20) UNIQUE NOT NULL,
    descripcion VARCHAR(100),
    color VARCHAR(7) DEFAULT '#6c757d'
);

-- Tabla incidencias (normalizada, sin categorías)
CREATE TABLE incidencias (
    id INT PRIMARY KEY AUTO_INCREMENT,
    titulo VARCHAR(200) NOT NULL,
    descripcion TEXT NOT NULL,
    estado_id INT NOT NULL DEFAULT 1,
    usuario_reporta_id INT NOT NULL,
    estudiante_involucrado_id INT,
    clase_id INT,
    imagen VARCHAR(255),
    fecha_incidencia DATETIME NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    resolucion TEXT,
    FOREIGN KEY (estado_id) REFERENCES estados_incidencia(id) ON DELETE RESTRICT,
    FOREIGN KEY (usuario_reporta_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (estudiante_involucrado_id) REFERENCES estudiantes(id) ON DELETE SET NULL,
    FOREIGN KEY (clase_id) REFERENCES clases(id) ON DELETE SET NULL
);

-- Insertar roles
INSERT INTO roles (nombre_rol, descripcion) VALUES 
('admin', 'Administrador del sistema'),
('profesor', 'Profesor de la institución'),
('estudiante', 'Estudiante matriculado');

-- Insertar personas (ejemplos para admin, profesores y estudiantes)
INSERT INTO personas (nombres, apellidos, dni, correo) VALUES 
('Admin', 'Sistema', '00000000', 'admin@escuela.edu.pe'),
('Juan', 'Pérez', '12345678', 'juan.perez@escuela.edu.pe'),
('María', 'González', '87654321', 'maria.gonzalez@escuela.edu.pe'),
('Carlos', 'López', '11111111', 'carlos.lopez@alumno.edu.pe'),
('Ana', 'Martínez', '22222222', 'ana.martinez@alumno.edu.pe'),
('Pedro', 'Sánchez', '33333333', 'pedro.sanchez@profesor.edu.pe'),
('Laura', 'Ramírez', '44444444', 'laura.ramirez@alumno.edu.pe');

-- Insertar usuarios (con contraseñas hashed de ejemplo)
INSERT INTO usuarios (persona_id, rol_id, contraseña) VALUES 
-- Admin (contraseña: 4P7R,vXcI0)
(1, 1, '$2y$12$oe/Ys10Wn0nOMnsxETkaF.pS3KK3f5Pv8AcE5N3pJVAz6cf6ktcBe'), 
(2, 2, '$2y$10$examplehashprofesor1'), -- Profesor Juan
(3, 2, '$2y$10$examplehashprofesor2'), -- Profesora María
(4, 3, '$2y$10$examplehashestudiante1'), -- Estudiante Carlos
(5, 3, '$2y$10$examplehashestudiante2'), -- Estudiante Ana
(6, 2, '$2y$10$examplehashprofesor3'), -- Profesor Pedro
(7, 3, '$2y$10$examplehashestudiante3'); -- Estudiante Laura

-- Insertar grados
INSERT INTO grados (nombre, nivel_numerico) VALUES 
('Primero', 1),
('Segundo', 2),
('Tercero', 3),
('Cuarto', 4),
('Quinto', 5),
('Sexto', 6);

-- Insertar secciones
INSERT INTO secciones (nombre, descripcion) VALUES 
('A', 'Sección A'),
('B', 'Sección B'),
('C', 'Sección C'),
('D', 'Sección D');

-- Insertar cursos
INSERT INTO cursos (nombre) VALUES 
('Matemáticas'),
('Comunicación'),
('Ciencias'),
('Historia'),
('Arte'),
('Educación Física');

-- Insertar dias_semana
INSERT INTO dias_semana (nombre, orden_dia) VALUES 
('Lunes', 1),
('Martes', 2),
('Miércoles', 3),
('Jueves', 4),
('Viernes', 5),
('Sábado', 6),
('Domingo', 7);

-- Insertar estudiantes
INSERT INTO estudiantes (persona_id, grado_id, seccion_id, codigo_estudiante, fecha_ingreso) VALUES 
(4, 1, 1, 'EST2025001', '2024-01-01'),
(5, 2, 2, 'EST2025002', '2024-01-01'),
(7, 3, 1, 'EST2025003', '2024-01-01');

-- Insertar profesores
INSERT INTO profesores (persona_id, especialidad, fecha_contratacion) VALUES 
(2, 'Matemáticas', '2023-01-01'),
(3, 'Comunicación', '2023-01-01'),
(6, 'Ciencias', '2023-01-01');

-- Insertar clases (agregada una clase adicional para Historia con id=4, usando un profesor existente)
INSERT INTO clases (curso_id, profesor_id, grado_id, seccion_id, dia_semana_id, hora_inicio, hora_fin, aula) VALUES 
(1, 1, 1, 1, 1, '08:00:00', '09:00:00', 'Aula 101'),
(2, 2, 2, 2, 2, '09:00:00', '10:00:00', 'Aula 102'),
(3, 3, 3, 1, 3, '10:00:00', '11:00:00', 'Aula 103'),
(4, 2, 2, 2, 4, '11:00:00', '12:00:00', 'Aula 104');  -- Nueva clase para Historia (curso_id=4)

-- Insertar estados_asistencia
INSERT INTO estados_asistencia (nombre, descripcion) VALUES 
('presente', 'Estudiante asistió a clase'),
('ausente', 'Estudiante no asistió'),
('justificado', 'Ausencia justificada');

-- Insertar asistencias
INSERT INTO asistencias (estudiante_id, clase_id, fecha, estado_id, observaciones) VALUES 
(1, 1, '2024-09-20', 1, NULL),
(2, 1, '2024-09-20', 1, NULL),
(1, 2, '2024-09-20', 2, 'Cita médica');

-- Insertar códigos de recuperación de contraseña
INSERT INTO recuperar_contraseña (usuario_id, codigo_unico, fecha_expiracion) VALUES 
(4, 'REC2024092001ABC123', DATE_ADD(NOW(), INTERVAL 24 HOUR)),
(5, 'REC2024092002XYZ789', DATE_ADD(NOW(), INTERVAL 24 HOUR));

-- Insertar estados_incidencia
INSERT INTO estados_incidencia (nombre, descripcion, color) VALUES 
('pendiente', 'Incidencia reportada, pendiente de revisión', '#ffc107'),
('en_revision', 'Incidencia en proceso de revisión', '#17a2b8'),
('resuelta', 'Incidencia resuelta satisfactoriamente', '#28a745'),
('cerrada', 'Incidencia cerrada sin resolución', '#6c757d');

-- Insertar incidencias (corregido: clase_id=4 ahora existe gracias a la clase agregada)
INSERT INTO incidencias (titulo, descripcion, estado_id, usuario_reporta_id, estudiante_involucrado_id, clase_id, fecha_incidencia) VALUES 
('Conflicto en el recreo', 'Estudiante Carlos tuvo un altercado verbal con otro compañero durante el recreo', 1, 2, 1, NULL, '2024-09-25 10:30:00'),
('Bajo rendimiento en matemáticas', 'La estudiante María muestra dificultades para comprender las fracciones', 2, 2, 2, 1, '2024-09-23 08:15:00'),
('Daño a silla del aula', 'Se encontró una silla rota en el aula A-101', 1, 3, NULL, 1, '2024-09-24 14:00:00'),
('Malestar durante clase', 'Estudiante Ana reportó dolor de cabeza durante la clase de historia', 3, 2, 2, 4, '2024-09-22 11:15:00');