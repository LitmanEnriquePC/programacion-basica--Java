-- Creación de la base de datos
CREATE DATABASE agenda_escolar;


-- BASE DE DATOS AGENDA ESCOLAR - NORMALIZADA (1FN, 2FN, 3FN)

-- ==============================================
-- PRIMERA FORMA NORMAL (1FN)
-- ==============================================
-- ✓ Eliminar grupos repetitivos
-- ✓ Cada campo contiene valores atómicos
-- ✓ Cada registro es único

-- ==============================================
-- SEGUNDA FORMA NORMAL (2FN)
-- ==============================================
-- ✓ Está en 1FN
-- ✓ Eliminar dependencias parciales
-- ✓ Todos los atributos no clave dependen completamente de la clave primaria

-- ==============================================
-- TERCERA FORMA NORMAL (3FN)
-- ==============================================
-- ✓ Está en 2FN
-- ✓ Eliminar dependencias transitivas
-- ✓ Ningún atributo no clave depende de otro atributo no clave

-- Tabla personas (entidad principal para datos comunes)
CREATE TABLE personas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombres VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    dni VARCHAR(8) UNIQUE NOT NULL,
    correo VARCHAR(100) UNIQUE NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla roles (normalizada para evitar dependencias transitivas)
CREATE TABLE roles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre_rol VARCHAR(20) UNIQUE NOT NULL,
    descripcion VARCHAR(100)
);

-- Tabla usuarios (sin redundancia de datos personales)
CREATE TABLE usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    persona_id INT NOT NULL,
    rol_id INT NOT NULL,
    contraseña VARCHAR(255) NOT NULL,
    activo BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (persona_id) REFERENCES personas(id) ON DELETE CASCADE,
    FOREIGN KEY (rol_id) REFERENCES roles(id) ON DELETE RESTRICT,
    UNIQUE KEY unique_persona_rol (persona_id, rol_id)
);

-- Tabla grados (normalizada)
CREATE TABLE grados (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(10) UNIQUE NOT NULL,
    nivel_numerico INT UNIQUE NOT NULL
);

-- Tabla secciones (normalizada)
CREATE TABLE secciones (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(5) UNIQUE NOT NULL,
    descripcion VARCHAR(50)
);

-- Tabla cursos (normalizada para evitar redundancia)
CREATE TABLE cursos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) UNIQUE NOT NULL
    
);

-- Tabla dias_semana (normalizada)
CREATE TABLE dias_semana (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(15) UNIQUE NOT NULL,
    orden_dia INT UNIQUE NOT NULL
);

-- Tabla estudiantes (solo información específica de estudiantes)
CREATE TABLE estudiantes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    persona_id INT NOT NULL,
    grado_id INT NOT NULL,
    seccion_id INT NOT NULL,
    codigo_estudiante VARCHAR(20) UNIQUE,
    fecha_ingreso DATE,
    FOREIGN KEY (persona_id) REFERENCES personas(id) ON DELETE CASCADE,
    FOREIGN KEY (grado_id) REFERENCES grados(id) ON DELETE RESTRICT,
    FOREIGN KEY (seccion_id) REFERENCES secciones(id) ON DELETE RESTRICT
);

-- Tabla profesores (solo información específica de profesores)
CREATE TABLE profesores (
    id INT PRIMARY KEY AUTO_INCREMENT,
    persona_id INT NOT NULL,
    especialidad VARCHAR(100),
    fecha_contratacion DATE,
    FOREIGN KEY (persona_id) REFERENCES personas(id) ON DELETE CASCADE
);

-- Tabla clases (completamente normalizada)
CREATE TABLE clases (
    id INT PRIMARY KEY AUTO_INCREMENT,
    curso_id INT NOT NULL,
    grado_id INT NOT NULL,
    seccion_id INT NOT NULL,
    profesor_id INT NOT NULL,
    dia_semana_id INT NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    aula VARCHAR(20),
    FOREIGN KEY (curso_id) REFERENCES cursos(id) ON DELETE CASCADE,
    FOREIGN KEY (grado_id) REFERENCES grados(id) ON DELETE RESTRICT,
    FOREIGN KEY (seccion_id) REFERENCES secciones(id) ON DELETE RESTRICT,
    FOREIGN KEY (profesor_id) REFERENCES profesores(id) ON DELETE CASCADE,
    FOREIGN KEY (dia_semana_id) REFERENCES dias_semana(id) ON DELETE RESTRICT
);

-- Tabla estados_asistencia (normalizada)
CREATE TABLE estados_asistencia (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(20) UNIQUE NOT NULL,
    descripcion VARCHAR(100)
);

-- Tabla asistencias (completamente normalizada)
CREATE TABLE asistencias (
    id INT PRIMARY KEY AUTO_INCREMENT,
    estudiante_id INT NOT NULL,
    clase_id INT NOT NULL,
    fecha DATE NOT NULL,
    estado_id INT NOT NULL,
    observaciones TEXT,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (estudiante_id) REFERENCES estudiantes(id) ON DELETE CASCADE,
    FOREIGN KEY (clase_id) REFERENCES clases(id) ON DELETE CASCADE,
    FOREIGN KEY (estado_id) REFERENCES estados_asistencia(id) ON DELETE RESTRICT,
    UNIQUE KEY unique_asistencia (estudiante_id, clase_id, fecha)
);

-- Tabla recuperar_contraseña (normalizada)
CREATE TABLE recuperar_contraseña (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    codigo_unico VARCHAR(100) UNIQUE NOT NULL,
    fecha_solicitud TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_expiracion DATETIME NOT NULL,
    usado BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);




-- NUEVO
-- Tabla estados_incidencia (normalizada)
CREATE TABLE estados_incidencia (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(20) UNIQUE NOT NULL,
    descripcion VARCHAR(100),
    color VARCHAR(7) DEFAULT '#6c757d'
);




-- ==============================================
-- INSERCIÓN DE DATOS NORMALIZADOS
-- ==============================================

-- Insertar roles
INSERT INTO roles (nombre_rol, descripcion) VALUES 
('admin', 'Administrador del sistema'),
('profesor', 'Docente del colegio'),
('estudiante', 'Alumno del colegio');

-- Insertar grados
INSERT INTO grados (nombre, nivel_numerico) VALUES 
('1ro', 1),
('2do', 2),
('3ro', 3),
('4to', 4),
('5to', 5),
('6to', 6);

-- Insertar secciones
INSERT INTO secciones (nombre, descripcion) VALUES 
('A', 'Sección A'),
('B', 'Sección B'),
('C', 'Sección C'),
('D', 'Sección D');

-- Insertar cursos
INSERT INTO cursos (nombre) VALUES 
('Matemáticas'),
('Comunicación'),
('Personal Social'),
('Ciencia y Tecnología'),
('Educacion Religiosa'),
('Arte y Cultura'),
('Educación Física'),
('Inglés');

-- Insertar días de la semana
INSERT INTO dias_semana (nombre, orden_dia) VALUES 
('Lunes', 1),
('Martes', 2),
('Miércoles', 3),
('Jueves', 4),
('Viernes', 5);

-- Insertar estados de asistencia
INSERT INTO estados_asistencia (nombre, descripcion) VALUES 
('presente', 'Estudiante presente en clase'),
('ausente', 'Estudiante ausente sin justificación'),
('justificado', 'Estudiante ausente con justificación');

-- Insertar personas
INSERT INTO personas (nombres, apellidos, dni, correo) VALUES 
-- Administrador
('Sistema', 'Administrador', '12345678', 'admin@colegio.edu.pe'),
-- Profesores
('María Elena', 'García Mendoza', '87654321', 'mgarcia@colegio.edu.pe'),
('José Antonio', 'Rodríguez Silva', '11223344', 'jrodriguez@colegio.edu.pe'),
('Ana Lucía', 'Sánchez Vargas', '55667788', 'asanchez@colegio.edu.pe'),
-- Estudiantes
('Carlos Andrés', 'Martínez Flores', '20001111', 'carlos.martinez@estudiante.colegio.pe'),
('María José', 'López Herrera', '20002222', 'maria.lopez@estudiante.colegio.pe'),
('Juan Carlos', 'Pérez Ramírez', '20003333', 'juan.perez@estudiante.colegio.pe'),
('Ana Sofía', 'Torres Castro', '20004444', 'ana.torres@estudiante.colegio.pe'),
('Luis Fernando', 'Vega Morales', '20005555', 'luis.vega@estudiante.colegio.pe'),
('Sofía Isabel', 'Ruiz Delgado', '20006666', 'sofia.ruiz@estudiante.colegio.pe');

-- Insertar usuarios
INSERT INTO usuarios (persona_id, rol_id, contraseña) VALUES 
-- Administrador
(1, 1, '$2y$12$wRtedYfuE3jnnWxAB8rDh.Lb.kQ.N6V..3wh/vOVRLMf0hHl7vGgm'),
-- Profesores
(2, 2, '$2y$12$pu33.AWRIOgCeKYO2XTBUO5rgMSe0cmLCXmh9Doa9HBiXdRIj4aKu'),
(3, 2, '$2b$10$pK8wFvN2LzT1QJdS9E7yJO.H3nF4P6eK2mR8sA7bC1xL9oY3pI5vW'),
(4, 2, '$2b$10$r9M1Kj8nO2Lp7Q4R6F3sE8.T5yH1N9oP2cV8bX4kM7dA6eI3wR5nJ'),
-- Estudiantes
(5, 3, '$2y$12$Ic3Scsufy8W9v0.3cecfIOSAmYgLy.VhU3.RtMuTgsyNdcFvVYjJe'),
(6, 3, '$2b$10$L8nO0qR3S6tU9vW2xY5zA7.B4cD8eG0iJ3kM6oP9qT2uV5wX8yZ1a'),
(7, 3, '$2b$10$M9oP1rS4T7uV0wX3yZ6aB8.C5dE9fH1jK4lN7pQ0rU3vW6xY9zA2b'),
(8, 3, '$2b$10$N0pQ2sT5U8vW1xY4zA7bC9.D6eF0gI2kL5mO8qR1sU4vW7xY0zB3c'),
(9, 3, '$2b$10$O1qR3tU6V9wX2yZ5aB8cD0.E7fG1hJ3lM6nP9rS2tU5vW8xY1zC4d'),
(10, 3, '$2b$10$P2rS4uV7W0xY3zA6bC9dE1.F8gH2iK4mN7oQ0sT3uV6wX9yZ2aD5e');

-- Insertar profesores
INSERT INTO profesores (persona_id, especialidad, fecha_contratacion) VALUES 
(2, 'Matemáticas', '2020-03-01'),
(3, 'Comunicación y Literatura', '2019-02-15'),
(4, 'Ciencias Naturales', '2021-01-10');

-- Insertar estudiantes
INSERT INTO estudiantes (persona_id, grado_id, seccion_id, codigo_estudiante, fecha_ingreso) VALUES 
(5, 3, 1, 'EST2024001', '2024-03-01'),  -- Carlos - 3ro A
(6, 3, 1, 'EST2024002', '2024-03-01'),  -- María - 3ro A
(7, 2, 2, 'EST2024003', '2023-03-01'),  -- Juan - 2do B
(8, 4, 3, 'EST2024004', '2022-03-01'),  -- Ana - 4to C
(9, 1, 4, 'EST2024005', '2025-03-01'),  -- Luis - 1ro D
(10, 5, 1, 'EST2024006', '2021-03-01'); -- Sofía - 5to A

-- Insertar clases
INSERT INTO clases (curso_id, grado_id, seccion_id, profesor_id, dia_semana_id, hora_inicio, hora_fin, aula) VALUES 
(1, 3, 1, 1, 1, '08:00:00', '08:45:00', 'A-101'), -- Matemáticas 3ro A
(2, 3, 1, 2, 1, '09:00:00', '09:45:00', 'A-102'), -- Comunicación 3ro A
(3, 2, 2, 3, 2, '10:00:00', '10:45:00', 'B-201'), -- Ciencias 2do B
(4, 4, 3, 1, 3, '11:00:00', '11:45:00', 'C-301'), -- Historia 4to C
(1, 1, 4, 2, 4, '08:00:00', '08:45:00', 'D-401'), -- Matemáticas 1ro D
(5, 5, 1, 3, 5, '14:00:00', '14:45:00', 'TALLER'), -- Arte 5to A
(6, 3, 1, 1, 5, '15:00:00', '15:45:00', 'PATIO');  -- Ed. Física 3ro A

-- Insertar asistencias
INSERT INTO asistencias (estudiante_id, clase_id, fecha, estado_id, observaciones) VALUES 
(1, 1, '2024-09-20', 1, NULL), -- Carlos presente en Matemáticas
(2, 1, '2024-09-20', 1, NULL), -- María presente en Matemáticas
(1, 2, '2024-09-20', 2, 'Cita médica'), -- Carlos ausente en Comunicación
(2, 2, '2024-09-20', 3, 'Permiso familiar'), -- María justificado en Comunicación
(3, 3, '2024-09-21', 1, NULL), -- Juan presente en Ciencias
(4, 4, '2024-09-22', 1, 'Excelente participación'), -- Ana presente en Historia
(5, 5, '2024-09-23', 2, 'Enfermedad'), -- Luis ausente en Matemáticas
(6, 6, '2024-09-24', 1, NULL), -- Sofía presente en Arte
(1, 7, '2024-09-24', 3, 'Competencia deportiva'); -- Carlos justificado en Ed. Física

-- Insertar códigos de recuperación de contraseña
INSERT INTO recuperar_contraseña (usuario_id, codigo_unico, fecha_expiracion) VALUES 
(5, 'REC2024092001ABC123', DATE_ADD(NOW(), INTERVAL 24 HOUR)),
(7, 'REC2024092002XYZ789', DATE_ADD(NOW(), INTERVAL 24 HOUR));







-- NUEVO
-- Agregar al archivo db.sql existente

-- Tabla estados_incidencia (normalizada)
CREATE TABLE estados_incidencia (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(20) UNIQUE NOT NULL,
    descripcion VARCHAR(100),
    color VARCHAR(7) DEFAULT '#6c757d'
);

-- Tabla incidencias (SIN categorías)
CREATE TABLE incidencias (
    id INT PRIMARY KEY AUTO_INCREMENT,
    titulo VARCHAR(200) NOT NULL,
    descripcion TEXT NOT NULL,
    estado_id INT NOT NULL DEFAULT 1,
    usuario_reporta_id INT NOT NULL,
    estudiante_involucrado_id INT,
    clase_id INT,
    imagen VARCHAR(255),
    fecha_incidencia DATETIME NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    resolucion TEXT,
    FOREIGN KEY (estado_id) REFERENCES estados_incidencia(id) ON DELETE RESTRICT,
    FOREIGN KEY (usuario_reporta_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (estudiante_involucrado_id) REFERENCES estudiantes(id) ON DELETE SET NULL,
    FOREIGN KEY (clase_id) REFERENCES clases(id) ON DELETE SET NULL
);

-- Insertar estados de incidencia
INSERT INTO estados_incidencia (nombre, descripcion, color) VALUES 
('pendiente', 'Incidencia reportada, pendiente de revisión', '#ffc107'),
('en_revision', 'Incidencia en proceso de revisión', '#17a2b8'),
('resuelta', 'Incidencia resuelta satisfactoriamente', '#28a745'),
('cerrada', 'Incidencia cerrada sin resolución', '#6c757d');

-- Insertar algunas incidencias de ejemplo
INSERT INTO incidencias (titulo, descripcion, estado_id, usuario_reporta_id, estudiante_involucrado_id, clase_id, fecha_incidencia) VALUES 
('Conflicto en el recreo', 'Estudiante Carlos tuvo un altercado verbal con otro compañero durante el recreo', 1, 2, 1, NULL, '2024-09-25 10:30:00'),
('Bajo rendimiento en matemáticas', 'La estudiante María muestra dificultades para comprender las fracciones', 2, 2, 2, 1, '2024-09-23 08:15:00'),
('Daño a silla del aula', 'Se encontró una silla rota en el aula A-101', 1, 3, NULL, 1, '2024-09-24 14:00:00'),
('Malestar durante clase', 'Estudiante Ana reportó dolor de cabeza durante la clase de historia', 3, 2, 4, 4, '2024-09-22 11:15:00');